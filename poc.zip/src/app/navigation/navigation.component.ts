import { Component, OnInit } from "@angular/core";

import { Category } from "./category";
import { CategoriesService } from "./categories.service";

@Component({
  selector: "app-navigation",
  templateUrl: "./navigation.component.html",
  styleUrls: ["./navigation.component.css"]
})
export class NavigationComponent implements OnInit {
  currentSubCatName: string;
  currentSubCatImage: string;
  errorMessage: string;
  categoriesList: Category[];

  constructor(private categoriesService: CategoriesService) {}

  ngOnInit() {
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
        this.currentSubCatImage = this.categoriesList[0]["image"];
      },
      error => (this.errorMessage = <string>error)
    );
  }
  //change image based on category
  setDynamicImage(nameValue, imageValue) {
    this.currentSubCatName = nameValue;
    this.currentSubCatImage = imageValue;
  }
}
