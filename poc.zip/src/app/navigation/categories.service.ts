import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { Category } from "./category";

@Injectable({
  providedIn: "root"
})
export class CategoriesService {
  private cartUrl = "./assets/json/categories.json";
  constructor(private httpService: HttpClient) {}

  // Call subcategories dynamicly
  getCategories(): Observable<Category[]> {
    return this.httpService.get<Category[]>(this.cartUrl);
  }
}
