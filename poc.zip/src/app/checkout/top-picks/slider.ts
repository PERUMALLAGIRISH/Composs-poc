export interface Slider {
  image: string;
  alt: string;
}
