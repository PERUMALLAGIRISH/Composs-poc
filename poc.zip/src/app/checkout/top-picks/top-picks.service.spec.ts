import { TestBed } from "@angular/core/testing";

import { TopPicksService } from "./top-picks.service";

describe("TopPicksService", () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it("should be created", () => {
    const service: TopPicksService = TestBed.get(TopPicksService);
    expect(service).toBeTruthy();
  });
});
