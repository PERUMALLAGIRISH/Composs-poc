import { Component, OnInit } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";


@Component({
  selector: "app-cart",
  templateUrl: "./cart.component.html",
  styleUrls: ["./cart.component.css"]
})
export class CartComponent implements OnInit {
  updatedCartList: any;
  updatedCartall: any;
  cartListData: any;
  errorMessage: any;
  currentUser: string;
  isLoggedIn: boolean;
  constructor(
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit() {
    if (localStorage.getItem("loggedUser")) {
      this.isLoggedIn = true;
      this.currentUser = localStorage.getItem("loggedUserEmail");
      this.updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
      this.updatedCartList = this.updatedCartall[0].cartData;

      if (this.updatedCartList.productData.length <= 0) {
        this.router.navigateByUrl("/");
        this.toastr.warning("Cart is empty");
      } else {
        this.cartListData = this.updatedCartList.productData.filter(
          isDelete => isDelete.isDeleted == false
        );
      }
    } else {
      this.isLoggedIn = false;
      this.router.navigateByUrl("/");
    }
  }

  // For quantity decreament
  qtyDecreament(event) {
    document.getElementById("navbar").style.display = "flex";
    var updatedValue: number;
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var minQty = 1;
    var id = event.target.id;
    var value = (<HTMLInputElement>document.getElementById("qty-" + id)).value;
    if (parseInt(value) && !isNaN(parseInt(value))) {
      updatedValue = parseInt(value) - 1;
      if (updatedValue >= minQty) {
        this.cartListData[id].quantity = updatedValue;
        this.cartListData[id].price =
          updatedValue * this.cartListData[id].productPrice;
        this.cartListData.forEach(element => {
          if (element.isDeleted == false) {
            updatedTotalQty += parseInt(element.quantity);
            updatedTotalPrice += element.price;
          }
        });
        this.updatedCartList.totalQuantity = updatedTotalQty;
        this.updatedCartList.subTotal = updatedTotalPrice;
        this.updatedCartList.grandTotal = this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
        localStorage.setItem(this.currentUser, JSON.stringify(this.updatedCartall));
        document.querySelector("#miniCart span").innerHTML = this.updatedCartList.totalQuantity;
      } else {
        this.toastr.error("Quantity should be minimum 1");
      }
    } else {
      this.toastr.error("Quantity should be minimum 1");
    }
  }

  // For quantity increament
  qtyIncreament(event) {
    var updatedValue: number;
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var maxQty = 5;
    var id = event.target.id;
    var value = (<HTMLInputElement>document.getElementById("qty-" + id)).value;
    if (parseInt(value) && !isNaN(parseInt(value))) {
      updatedValue = parseInt(value) + 1;
      this.cartListData[id].quantity = updatedValue;
      this.cartListData[id].price = updatedValue * this.cartListData[id].productPrice;
      this.cartListData.forEach(element => {
        if (element.isDeleted == false) {
          updatedTotalQty += parseInt(element.quantity);
          updatedTotalPrice += element.price;
        }
      });
      this.updatedCartList.totalQuantity = updatedTotalQty;
      this.updatedCartList.subTotal = updatedTotalPrice;
      this.updatedCartList.grandTotal = this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
      localStorage.setItem(this.currentUser, JSON.stringify(this.updatedCartall));
      document.querySelector("#miniCart span").innerHTML = this.updatedCartList.totalQuantity;
    } else {
      this.toastr.error("Quantity should be minimum 1");
    }
  }

  // For Delete cart item
  deleteCart(event) {
    var itemInCartId = "itemInCart-" + event.target.id;
    var delItemInCartId = "delItemInCart-" + event.target.id;
    document.getElementById(itemInCartId).style.display = "none";
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var id = event.target.id;
    this.cartListData[id].isDeleted = true;
    var isCart: boolean = true;

    this.cartListData.forEach(item => {
      if (item.isDeleted == false) {
        updatedTotalQty += parseInt(item.quantity);
        updatedTotalPrice += item.price;
        isCart = false;
      }
    });
    if (isCart) {
      document.getElementById(delItemInCartId).style.display = "none";
      location.reload();
    } else {
      document.getElementById(delItemInCartId).style.display = "flex";
    }
    this.updatedCartList.totalQuantity = updatedTotalQty;
    this.updatedCartList.subTotal = updatedTotalPrice;
    this.updatedCartList.grandTotal = this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
    setTimeout(function () {
      document.getElementById(delItemInCartId).style.display = "none";
    }, 9000);
    localStorage.setItem(this.currentUser, JSON.stringify(this.updatedCartall));
    if (this.updatedCartall[0].cartData.totalQuantity == 0) {
      var item = document.querySelector("#miniCart span");
      item.parentNode.removeChild(item);
    } else {
      document.querySelector("#miniCart span").innerHTML = this.updatedCartList.totalQuantity;
    }
  }

  undoCart(event) {
    var itemInCartId = "itemInCart-" + event.target.id;
    var delItemInCartId = "delItemInCart-" + event.target.id;
    document.getElementById(itemInCartId).style.display = "flex";
    document.getElementById(delItemInCartId).style.display = "none";
    var updatedTotalQty: number = 0;
    var updatedTotalPrice: number = 0;
    var id = event.target.id;
    this.cartListData[id].isDeleted = false;
    this.cartListData.forEach(item => {
      if (item.isDeleted == false) {
        updatedTotalQty += parseInt(item.quantity);
        updatedTotalPrice += item.price;
      }
    });
    this.updatedCartList.totalQuantity = updatedTotalQty;
    this.updatedCartList.subTotal = updatedTotalPrice;
    this.updatedCartList.grandTotal = this.updatedCartList.subTotal + this.updatedCartList.shippingCharge;
    localStorage.setItem(this.currentUser, JSON.stringify(this.updatedCartall));

    if (this.updatedCartall[0].cartData.totalQuantity == 0) {
      var item = document.querySelector("#miniCart span");
      item.parentNode.removeChild(item);
    } else {
      document.querySelector(
        "#miniCart span"
      ).innerHTML = this.updatedCartList.totalQuantity;
    }
  }

  shopBtnClick() {
    this.router.navigateByUrl("/");
  }

  checkoutBtnClick() {
    this.router.navigateByUrl("/checkout");
  }
}
