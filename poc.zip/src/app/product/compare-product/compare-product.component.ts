import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-compare-product",
  templateUrl: "./compare-product.component.html",
  styleUrls: ["./compare-product.component.css"]
})
export class CompareProductComponent implements OnInit {
  recentProduct: any;
  userDetails: any;
  compareProduct: any;
  currentUser: string;
  isCmprPrd: boolean;
  constructor(private router: Router) { }

  ngOnInit() {
    if (localStorage.getItem("loggedUser")) {
      this.currentUser = localStorage.getItem("loggedUserEmail");
      this.userDetails = JSON.parse(localStorage.getItem(this.currentUser));
      this.compareProduct = this.userDetails[0].comparePrd;
      if (this.compareProduct && this.compareProduct.length > 0) {
        this.isCmprPrd = true;
      } else {
        this.isCmprPrd = false;
      }
    } else {
      this.router.navigateByUrl("/");
    }
  }

  deleteItemFromCompareList(e) {
    var id = e.target.id;
    this.compareProduct.splice(id, 1);
    document.getElementById("header-compare").innerHTML = "Compare Product(" + this.compareProduct.length + ")";
    localStorage.setItem(this.currentUser, JSON.stringify(this.userDetails));
  }
}
