import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { Slider } from "../home/slider";

@Injectable({
  providedIn: "root"
})
export class SliderService {
  private sliderUrl = "../assets/json/images.json";

  constructor(private http: HttpClient) {}

  //Get slider data dynamicly
  getSlider(): Observable<Slider[]> {
    return this.http.get<Slider[]>(this.sliderUrl);
  }
}
