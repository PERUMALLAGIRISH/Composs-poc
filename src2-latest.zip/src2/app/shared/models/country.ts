export class Country {
    id: number;
    name: string;
    isocode: string;
    description: string;
}
