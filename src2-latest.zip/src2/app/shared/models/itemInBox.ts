export class ItemInBox {
    id: number;
    key: string;
    value: string;
    type: string;
}