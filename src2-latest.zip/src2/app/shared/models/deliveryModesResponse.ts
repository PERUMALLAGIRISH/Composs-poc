import { DeliveryMode } from "src/app/shared/models/deliveryMode";

export class DeliveryModesResponse {
    data: DeliveryMode[];
}