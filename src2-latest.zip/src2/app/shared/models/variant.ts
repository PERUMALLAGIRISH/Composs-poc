import { Price } from "src/app/shared/models/price";
import { Stock } from "src/app/shared/models/stock";
import { MemorySize } from "src/app/shared/models/memorySize";
import { Color } from "src/app/shared/models/color";

export class Variant {
    id: number;
    variantId: string;
    variantType: string;
    sequenceNumber: number;
    shortDescription: number;
    prices: Price[];
    stock: Stock;
    memorySize: MemorySize;
    color: Color;
}