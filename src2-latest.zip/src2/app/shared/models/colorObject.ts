import { Color } from "src/app/shared/models/color";
import { Media } from "src/app/shared/models/media";

export class ColorObject {
    color: Color;
    medias: Media[];
}