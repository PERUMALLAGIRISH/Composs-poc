import { Cart } from "src/app/shared/models/cart";

export class CartResponse {
    data: Cart;
    technicalError: string;
    businessError: string;
}