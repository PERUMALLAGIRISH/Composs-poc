export class Media {
    id: number;
    colorId: string;
    url: string;
    mediaSequenceId: number;
    primary: boolean;
}