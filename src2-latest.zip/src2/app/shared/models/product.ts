import { Media } from "src/app/shared/models/media";
import { Variant } from "src/app/shared/models/variant";
import { ColorObject } from "src/app/shared/models/colorObject";
import { MemorySize } from "src/app/shared/models/memorySize";
import { Specification } from "src/app/shared/models/specification";
import { ItemInBox } from "src/app/shared/models/itemInBox";

export class Product {
    id: number;
    productId: string;
    name: string;
    shortDescription: string;
    description: string;
    productType: string;
    minOrderQuantity: number;
    maxOrderQuantity: number;
    variants: Variant[];
    colors: ColorObject[];
    memories: MemorySize[];
    specifications: Specification[];
    itemsInBox: ItemInBox[];
    active: boolean;
    availableForPichup: boolean;
    purchasable: boolean;
}