import { Card } from "src/app/shared/models/card";

export class CardResponse {
    data: Card[];
}