import { BillingAddress } from "src/app/shared/models/billingAddress";
import { ShippingAddress } from "src/app/shared/models/shippingAddress";
import { Entry } from "src/app/shared/models/entry";
import { DeliveryMode } from 'src/app/shared/models/deliveryMode';

export class Order {
    id: number;
    totalItems: number;
    totalPrice: number;
    totalTax: number;
    totalPriceWithTax: number;
    defaultDeliveryDate: string;
    requestedDeliveryDate: string;
    instructions: string;
    status: string;
    billingAddress: BillingAddress;
    deliveryMode: DeliveryMode;
    shippingAddress: ShippingAddress;
    entries: Entry[];
}