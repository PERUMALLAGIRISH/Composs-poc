import { Order } from "src/app/shared/models/order";

export class OrderResponse {
    data: Order;
}