export class CheckoutResponse {
    data: string;
}