export class Price {
    id: number;
    currency: string;
    priceValue: number;
    locale: string;
}
