import { User } from "src/app/shared/models/user";

export class LoginResponse {
    data: User;
    technicalError: string;
}