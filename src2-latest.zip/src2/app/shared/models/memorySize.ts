export class MemorySize {
    id: number;
    memorySizeValue: string;
    sequenceNumber: number;
    description: string; 
}