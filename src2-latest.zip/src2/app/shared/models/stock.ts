export class Stock {
    id: number;
    stockValue: string;
    minThreshold: string;
    maxThreshold: string;
}