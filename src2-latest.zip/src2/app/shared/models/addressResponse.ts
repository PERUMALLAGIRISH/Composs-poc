import { BillingAddress } from "src/app/shared/models/billingAddress";

export class AddressResponse {
    data: BillingAddress[];
}