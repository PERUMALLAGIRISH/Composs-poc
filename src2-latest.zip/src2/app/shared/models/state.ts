export class State {
    id: string;
    name: string;
    isocode: string;
    description: string;
}
