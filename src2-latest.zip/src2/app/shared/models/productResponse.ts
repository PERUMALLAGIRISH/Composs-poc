import { Product } from "src/app/shared/models/product";

export class ProductResponse {
    data: Product;
}