export class Specification {
    id: number;
    key: string;
    value: string;
    type: string;
}