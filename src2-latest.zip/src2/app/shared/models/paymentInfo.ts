import { Card } from "src/app/shared/models/card";

export class PaymentInfo {
    id: number;
    paymentType: string;
    creditCard: Card;
    amount: number;
    status: string;
    transactionDate: string;
}