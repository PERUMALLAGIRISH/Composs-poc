export class Color {
    id: number;
    colorId: string;
    description: string;
    colorIconUrl: string;
    sequenceNumber: number;
}