export class Image {
    url: string; 
    name: string;
}