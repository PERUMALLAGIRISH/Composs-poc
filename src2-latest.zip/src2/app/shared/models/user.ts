export class User {
    id: number;
    userId: string;
    firstName: string;
    lastName: string;
    title: string;
}