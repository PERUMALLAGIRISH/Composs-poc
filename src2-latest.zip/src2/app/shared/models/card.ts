export class Card {
    id: number;
    cardNumber: string;
    cardType: string;
    expiryMonth: number;
    expiryYear: number; 
    lastName: string;
    firstName: string;
}