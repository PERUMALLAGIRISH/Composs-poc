import { Product } from "src/app/shared/models/product";

export class SearchResponse {
    data: Product[];
}