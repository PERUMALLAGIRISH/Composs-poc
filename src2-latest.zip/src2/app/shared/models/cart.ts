import { BillingAddress } from "src/app/shared/models/billingAddress";
import { ShippingAddress } from "src/app/shared/models/shippingAddress";
import { Entry } from "src/app/shared/models/entry";
import { PaymentInfo } from "src/app/shared/models/paymentInfo";

export class Cart {
    id: string;
    totalItems: number;
    totalPrice: number;
    totalTax: number;
    totalPriceWithTax: number;
    defaultDeliveryDate: string;
    requestedDeliveryDate: string;
    billingAddress: BillingAddress;
    deliveryMode: string;
    shippingAddress: ShippingAddress;
    paymentInfos: PaymentInfo;
    entries: Entry[];
}