export class DeliveryMode {
    id: number;
    deliveryModeId: string;
    name: string;
    description: string;
}