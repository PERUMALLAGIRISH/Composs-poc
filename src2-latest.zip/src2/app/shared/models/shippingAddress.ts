import { Country } from "src/app/shared/models/country";
import { State } from "src/app/shared/models/state";

export class ShippingAddress {
    id: number;
    erpAddressId: string;
    firstName: string;
    lastName: string;
    titleCode: string;
    postalCode: string;
    line1: string;
    line2: string;
    town: string;
    defaultAddress: boolean;
    country: Country;
    state: State;
}
