import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { DeliveryMode } from '../models/deliveryMode';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

import { AddressResponse } from 'src/app/shared/models/addressResponse';
import { DeliveryModesResponse } from 'src/app/shared/models/deliveryModesResponse';
import { CheckoutResponse } from 'src/app/shared/models/checkoutResponse';
import { OrderResponse } from 'src/app/shared/models/orderResponse';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class CheckoutService {
  private API_URL: string = environment.apiUrl;
  private USERS_URL: string = environment.usersUrl;
  private USER_URL: string = environment.userUrl;
  private USER_ID_URL: string = "/" + localStorage.getItem('userId');
  private ADDRESSES_URL: string = environment.addressesUrl;
  private DELIVERY_MODES_URL: string = environment.deliveryModesUrl;
  private CART_ID_URL: string = "/" + localStorage.getItem('cartId')
  private CHECKOUT_URL: string = environment.checkoutUrl;
  private SHIPPING_URL: string = environment.shippingUrl;
  private PAYMENT_URL: string = environment.paymentUrl;
  private CREDIT_CARDS_URL: string = environment.creditCardsUrl;
  private PLACE_ORDER_URL: string = environment.placeOrderUrl;
  // private CHECKOUT_URL: string = environment.checkoutUrl;
  // private SHIPPING_URL: string = environment.shippingUrl;
  
  
  constructor(private http: HttpClient) { }

  getAddressList(): Observable<AddressResponse> {
    const url = this.API_URL + this.USERS_URL + this.USER_URL + this.USER_ID_URL + this.ADDRESSES_URL;
    return this.http.get<AddressResponse>(url);
    
  }
  getDeliveryModes(): Observable<DeliveryModesResponse> {
    const url = this.API_URL + this.DELIVERY_MODES_URL;
    return this.http.get<DeliveryModesResponse>(url);   
  }
  saveAddressToCart(addressId: number, deliveryModeId: string): Observable<CheckoutResponse> {
    let body = {
      "shippingAddressId": addressId,
      "requestedDeliveryDate": "2018-07-29",
      "defaultDeliveryDate": "2018-10-19",
      "deliveryModeId": deliveryModeId
    };
    const url = this.API_URL + this.USERS_URL + this.USER_ID_URL 
                + this.CHECKOUT_URL + this.SHIPPING_URL;
    return this.http.put<CheckoutResponse>(url,body,httpOptions);            
  } 
  savePaymentDetailsToCart(amount: number): Observable<CheckoutResponse> {
    let body = {
      "paymentType": "CREDITCARD",
      "creditCardid": 3,
      "amount": amount,
      "status": 1,
      "transactionDate":"2018-09-10"
    }
    const url = this.API_URL + this.USERS_URL + this.USER_ID_URL 
                + this.CHECKOUT_URL + this.PAYMENT_URL;
    return this.http.put<CheckoutResponse>(url, body, httpOptions);            
  } 
  placeOrder(): Observable<OrderResponse> {
    const url = this.API_URL + this.USERS_URL + this.USER_ID_URL + this.PLACE_ORDER_URL;
    return this.http.post<OrderResponse>(url, httpOptions);
  }
}
