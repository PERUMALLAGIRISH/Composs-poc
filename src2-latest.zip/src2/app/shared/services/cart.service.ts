import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Cart } from '../models/cart';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CartResponse } from 'src/app/shared/models/cartResponse';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class CartService {
  //private cartUrl = 'localhost:3000/data';
  private API_URL: string = environment.apiUrl;
  private CARTS_URL: string = environment.cartsUrl;
  private CART_URL: string = environment.cartUrl;
  private USERS_URL: string = environment.usersUrl;
  private USER_URL: string = environment.userUrl;
  private USER_ID_URL: string = "/" + localStorage.getItem('userId');
  private ADDTOCART_URL: string = environment.addToCartUrl;
  
  constructor(private http: HttpClient) { }
  
  getCart(): Observable<CartResponse> {
    const url = this.API_URL + this.USERS_URL + this.USER_ID_URL + this.CART_URL;
    return this.http.get<CartResponse>(url);
  }
  addToCart(variantId, quantity): Observable<any>{
    let body = {
      "variantId": variantId,
      "quantity": quantity
    }
    const url = this.API_URL + this.USERS_URL + this.USER_ID_URL + this.CARTS_URL + this.ADDTOCART_URL;
    return this.http.post<any>(url, body, httpOptions);
  }
}