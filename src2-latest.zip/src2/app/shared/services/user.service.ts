import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { LoginResponse } from 'src/app/shared/models/LoginResponse';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private API_URL: string = environment.apiUrl;
  private USERS_URL: string = environment.usersUrl;
  private AUTHENTICATE_URL: string = environment.authenticateUrl;
  constructor(private http: HttpClient) { }

  login(userId: string, password: string): Observable<LoginResponse> {
    let body = {
      "userId": userId,
      "password": password
    };
    const url = this.API_URL+this.USERS_URL+this.AUTHENTICATE_URL;
    return this.http.post<LoginResponse>(url, body, httpOptions);
  }
}
