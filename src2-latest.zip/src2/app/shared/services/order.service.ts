import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { OrderResponse } from 'src/app/shared/models/orderResponse';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private API_URL: string = environment.apiUrl;
  private USERS_URL: string = environment.usersUrl;
  private USER_URL: string = environment.userUrl;
  private USER_ID_URL: string = "/" + localStorage.getItem('userId');
  private ORDERS_URL: string = environment.ordersUrl;
  private ORDER_URL: string = environment.orderUrl;
  private ORDER_ID_URL: string = "/" + localStorage.getItem("orderId");
  constructor(private http: HttpClient) { }

  getOrderDetails(): Observable<OrderResponse> {
    const url = this.API_URL + this.USERS_URL + this.USER_URL + this.USER_ID_URL + this.ORDERS_URL + this.ORDER_URL + this.ORDER_ID_URL;
    return this.http.get<OrderResponse>(url);
  }
}
