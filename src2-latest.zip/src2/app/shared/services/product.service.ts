import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ProductResponse } from 'src/app/shared/models/productResponse';
import { SearchResponse } from 'src/app/shared/models/searchResponse';

@Injectable({
    providedIn: 'root'
})
export class ProductService {
  private API_URL: string = environment.apiUrl;
  private PRODUCTS_URL: string = environment.productsUrl;
  private PRODUCT_URL: string = environment.productUrl;
  
  constructor(private http: HttpClient) { }
  
  getProduct(productId: string): Observable<ProductResponse> {
    const url ="http://localhost:3001/pdp";
    //const url = this.API_URL + this.PRODUCTS_URL + this.PRODUCT_URL + "/" + productId + "?locale='en_US'";
    return this.http.get<ProductResponse>(url);
  }

  searchProducts(): Observable<SearchResponse> {
    const url = this.API_URL + this.PRODUCTS_URL;
    return this.http.get<SearchResponse>(url);
  }
}
