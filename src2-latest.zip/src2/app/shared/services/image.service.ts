import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Image } from 'src/app/shared/models/image';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  constructor(private http: HttpClient) { }

  getBannerImages(): Observable<Image[]> {
    const url = "http://localhost:3000/bannerImages";
    return this.http.get<Image[]>(url);
  }

  getCategoryImages(): Observable<Image[]> {
    const url = "http://localhost:3000/categoryImages";
    return this.http.get<Image[]>(url);
  }

  getFeaturedProductsImages(): Observable<Image[]> {
    const url = "http://localhost:3000/featuredProducts";
    return this.http.get<Image[]>(url);
  }

}
