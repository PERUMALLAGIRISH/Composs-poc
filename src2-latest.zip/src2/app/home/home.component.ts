import { Component, OnInit } from "@angular/core";
import { OtherService } from "../services/other.services";
import { Slider } from "./slider";
import { CategoriesService } from "../navigation/categories.service";
import { Category } from "../navigation/category";
import { Iproduct } from "../product/product";
import { ProductserviceService } from "../services/product.services";
import { DeviceDetectorService } from "ngx-device-detector";
import { Image } from 'src/app/shared/models/image';
import { ImageService } from 'src/app/shared/services/image.service';

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  sliderArray: Slider[];
  categoriesList: Category[];
  myInterval: number = 2500;
  activeSlideIndex = 0;
  errorMessage: any;
  featureProduct: Iproduct[];
  filteredItems: any;
  showIcon: boolean = false;
  isMobile: boolean = false;
  chunks_value: number;
  // isActive:boolean=false;
  // imgSrc:any;


  bannerImages: Image[];
  categoryImages: Image[];
  featuredProductImages: Image[];

  constructor(
    public slider: OtherService,
    private categoriesService: CategoriesService,
    private Productservice: ProductserviceService,
    private deviceService: DeviceDetectorService,
    private imageService: ImageService
  ) {
    this.sliderArray = [];
  }

  getBannerImages() {
    this.imageService.getBannerImages()
    .subscribe(
      data => {
        this.bannerImages = data;
        console.log(this.bannerImages);
      }
    )
  }

  getCategoryImages() {
    this.imageService.getCategoryImages()
    .subscribe(
      data => {
        this.categoryImages = data;
        console.log(this.categoryImages);
      }
    )
  }

  getFeaturedProductImages() {
    this.imageService.getFeaturedProductsImages()
    .subscribe(
      data => {
        this.featuredProductImages = this.chunks(data, this.chunks_value);
        console.log(this.featuredProductImages);
      }
    )
  }

  ngOnInit() {
    this.getBannerImages();
    this.getCategoryImages();
    this.getFeaturedProductImages();
    this.isMobile = this.deviceService.isMobile();
    if (this.isMobile) {
      this.chunks_value = 1;
    } else {
      this.chunks_value = 3;
    }
    // document.getElementById("navbar").style.display = "block";
    // this.slider.getSlider().subscribe((result: Slider[] = []) => {
    //   this.sliderArray = result;
    //   //console.log(this.sliderArray);
    //   this.sliderArray = this.sliderArray;
    // });
    // this.categoriesService.getCategories().subscribe(
    //   data => {
    //     this.categoriesList = data;
    //   },
    //   error => (this.errorMessage = <any>error)
    // );
    
    // this.Productservice.getProducts().subscribe(data => {
    //   this.featureProduct = this.chunks(data, this.chunks_value);
    // });
    var dots = document.getElementById("more");
    dots.style.display = "none";
  }

  chunks(array, size) {
    let results = [];
    results = [];
    while (array.length) {
      results.push(array.splice(0, size));
    }
    return results;
  }

  toggleSign(arg): void {
    let id = document.getElementById(arg);
    var src = id.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    id.setAttribute("src", src);
  }
  ReadMoreBtn() {
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("readMoreTextBtn");
    if (moreText.style.display == "none") {
      // dots.style.display = "inline";
      btnText.innerHTML = "Read less";
      moreText.style.display = "block";
    } else {
      btnText.innerHTML = "Read more";
      //moreText.style.display = "inline";
      moreText.style.display = "none";
    }
  }
  toggleImage() {
    this.showIcon = !this.showIcon;
  }
}
