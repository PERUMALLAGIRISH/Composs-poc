import { Component, OnInit } from "@angular/core";
import { ProductserviceService } from "../services/product.services";
import { Iproduct } from "./product";
import { PageChangedEvent } from "ngx-bootstrap/pagination";
import { ActivatedRoute, Router } from "@angular/router";
import { CategoriesService } from "../navigation/categories.service";

@Component({
  selector: "app-product",
  templateUrl: "./product.component.html",
  styleUrls: ["./product.component.css"]
})
export class ProductComponent implements OnInit {
  products: Iproduct[] = [];
  sortName: boolean = true;
  sortPrice: boolean = true;
  sortStar: boolean = true;
  str;
  imgmar: number = 2;
  isActive: boolean = true;
  isAsc: number = 0;
  contentArray = new Array().fill("");
  returnedArray: Iproduct[];
  categoryFilter: Iproduct[];
  filteredProducts: Iproduct[];
  filteredBrandProducts: Iproduct[];
  filteredPriceProducts: Iproduct[];
  categoryProducts: Iproduct[];
  allProduct: Iproduct[];
  selectedBrandCheckBoxes = [];
  selectedPriceCheckBoxes = [];
  brands = [];
  brandsUnique;
  categoryName: any;
  pId;
  check = false;
  showCategories;
  showBrands;
  showPrices;
  status: boolean = false;

  constructor(
    private productService: ProductserviceService,
    private route: ActivatedRoute,
    private CategoryService: CategoriesService,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.params.subscribe(routeParams => {
      this.pId = routeParams.id;
      this.CategoryService.getCategories().subscribe(data => {
        this.categoryName = data.filter(
          category => category.categoryId == this.pId
        );
        this.categoryName = this.categoryName[0].name;
      });

      this.productService.getProducts().subscribe(data => {
        this.categoryFilter = data.filter(
          product => product.category_id == this.pId
        );
        this.products = this.categoryFilter;
        for (var brand = 0; brand < this.products.length; brand++) {
          this.brands.push(this.products[brand].brand);
        }
        this.brandsUnique = this.brands.filter(function(item, i, ar) {
          return ar.indexOf(item) === i;
        });
        this.contentArray = this.categoryFilter;
        this.returnedArray = this.contentArray.slice(0, 6);
      });
    });
  }

  pageChanged(event: PageChangedEvent): void {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.returnedArray = this.contentArray.slice(startItem, endItem);
  }

  toggleSign(arg): void {
    let id = document.getElementById(arg);
    var src = id.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    id.setAttribute("src", src);
  }
  sortByName() {
    this.status = !this.status;
    var page = document.querySelector("pagination .active a").innerHTML;
    document.getElementById("drop-button").innerHTML = "&nbsp;Name";
    this.allProduct = this.categoryFilter;
    if (this.sortName === true) {
      this.allProduct.sort(this.sortByNameAsc);
      this.sortName = false;
      this.pageSlice(page, 6, this.allProduct);
    } else {
      this.allProduct.sort(this.sortByNameAsc).reverse();
      this.sortName = true;
      this.pageSlice(page, 6, this.allProduct);
    }
  }
  sortByNameAsc(a: Iproduct, b: Iproduct) {
    if (a.name > b.name) return 1;
    else if (a.name === b.name) return 0;
    else return -1;
  }

  sortByPrice() {
    this.status = !this.status;
    var page = document.querySelector("pagination .active a").innerHTML;
    document.getElementById("drop-button").innerHTML = "&nbsp;Price";
    this.allProduct = this.categoryFilter;
    if (this.sortPrice === true) {
      this.allProduct.sort(this.sortByPriceAsc);
      this.sortPrice = false;
      this.pageSlice(page, 6, this.allProduct);
    } else {
      this.allProduct.sort(this.sortByPriceAsc).reverse();
      this.sortPrice = true;
      this.pageSlice(page, 6, this.allProduct);
    }
  }

  sortByPriceAsc(a: Iproduct, b: Iproduct) {
    if (a.price > b.price) return 1;
    else if (a.price === b.price) return 0;
    else return -1;
  }

  sortByStar() {
    this.status = !this.status;
    var page = document.querySelector("pagination .active a").innerHTML;
    document.getElementById("drop-button").innerHTML = "&nbsp;Star Rating";
    this.allProduct = this.categoryFilter;
    if (this.sortStar === true) {
      this.allProduct.sort(this.sortByStarAsc);
      this.sortStar = false;
      this.pageSlice(page, 6, this.allProduct);
    } else {
      this.allProduct.sort(this.sortByStarAsc).reverse();
      this.sortStar = true;
      this.pageSlice(page, 6, this.allProduct);
    }
  }

  sortByStarAsc(a: Iproduct, b: Iproduct) {
    if (a.rating > b.rating) return 1;
    else if (a.rating === b.rating) return 0;
    else return -1;
  }

  sorting() {
    if (document.getElementById("drop-button").innerHTML === "&nbsp;Name") {
      this.sortByName();
    } else if (
      document.getElementById("drop-button").innerHTML === "&nbsp;Price"
    ) {
      this.sortByPrice();
    } else if (
      document.getElementById("drop-button").innerHTML === "&nbsp;Star Rating"
    ) {
      this.sortByStar();
    }
  }

  pageSlice(page, itemsPerPage, contentArray) {
    const startItem = (page - 1) * itemsPerPage;
    const endItem = page * itemsPerPage;
    this.returnedArray = contentArray.slice(startItem, endItem);
    return this.returnedArray;
  }

  addprop1(eventData) {
    if (eventData === "brand") {
      // console.log("eventData:::"+eventData);
      this.check = true;
      var brandCheckboxes = document.querySelectorAll(
          'input[name="' + eventData + '"]:checked'
        ),
        brandValues = [];
      Array.prototype.forEach.call(brandCheckboxes, function(el) {
        brandValues.push(el.value);
      });
      this.selectedBrandCheckBoxes = brandValues;
      if (brandValues.length != 0) {
        this.filteredBrandProducts = this.products.filter(function(element) {
          return brandValues.indexOf(element.brand) > -1;
        });
      }
    } else if (eventData === "price") {
      this.check = true;
      var priceCheckboxes = document.querySelectorAll(
          'input[name="' + eventData + '"]:checked'
        ),
        priceValues = [];
      Array.prototype.forEach.call(priceCheckboxes, function(el) {
        priceValues.push(el.value);
      });

      this.selectedPriceCheckBoxes = priceValues;

      if (priceValues.length != 0) {
        var productsDataArr = [];
        this.filteredPriceProducts = this.products.filter(function(element) {
          var prodPrice = element.price;
          for (var i = 0; i < priceValues.length; i++) {
            var data = priceValues[i].split("to");
            var priceMinValue = parseInt(data[0]);
            var priceMaxValue = parseInt(data[1]);

            if (prodPrice >= priceMinValue && prodPrice <= priceMaxValue) {
              productsDataArr.push(element);
              return productsDataArr.slice(0, 6);
            }
          }
        });
      }
    }
    var brand = document.querySelectorAll(
      'input[name="' + "brand" + '"]:checked'
    );
    var price = document.querySelectorAll(
      'input[name="' + "price" + '"]:checked'
    );

    if (brand.length != 0 && price.length != 0) {
      var commonElementArray = [];
      var arr = [];
      var a = this.filteredBrandProducts;
      var b = this.filteredPriceProducts;
      for (var i = 0; i < a.length; i++) {
        for (var j = 0; j < b.length; j++) {
          if (a[i].productId === b[j].productId) {
            commonElementArray.push(a[i]);
          }
        }
      }
      this.contentArray = commonElementArray;
      this.returnedArray = commonElementArray.slice(0, 6);
    }
    if (brand.length != 0 && price.length == 0) {
      this.contentArray = this.filteredBrandProducts;
      this.returnedArray = this.filteredBrandProducts.slice(0, 6);
    }
    if (brand.length == 0 && price.length != 0) {
      this.contentArray = this.filteredPriceProducts;
      this.returnedArray = this.filteredPriceProducts.slice(0, 6);
    }
    if (brand.length == 0 && price.length == 0) {
      this.check = false;
      this.contentArray = this.products;
      this.returnedArray = this.products.slice(0, 6);
    }
  }

  disableBrandSelected(e) {
    var val = e.target.id;
    var eventData = document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).name;
    document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).checked = false;
    this.addprop1(eventData);
  }

  disablePriceSelected(e) {
    var val = JSON.stringify(e.target.id);
    // console.log("val:::"+document.querySelector<HTMLInputElement>('[value^='+val+']'));
    var eventData = document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).name;
    document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).checked = false;
    this.addprop1(eventData);
  }

  clearAll() {
    if (
      document.querySelectorAll<HTMLInputElement>("[id^=selectedBrandCheck]")
    ) {
      var elems = document.querySelectorAll<HTMLInputElement>(
        "[id^=selectedBrandCheck]"
      );
      //document.querySelectorAll<HTMLInputElement>('[name^=brand]').checked = false;
      for (var i = 0; i < elems.length; i++) {
        elems[i].remove();
      }
      var items = document.querySelectorAll<HTMLInputElement>("[name^=brand]");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type == "checkbox") items[i].checked = false;
      }
      var eventData = document.querySelector<HTMLInputElement>("[name^=brand]")
        .name;
      this.addprop1(eventData);
    }

    if (
      document.querySelectorAll<HTMLInputElement>("[id^=selectedPriceCheck]")
    ) {
      var elems = document.querySelectorAll<HTMLInputElement>(
        "[id^=selectedPriceCheck]"
      );
      for (var i = 0; i < elems.length; i++) {
        elems[i].remove();
      }
      var items = document.querySelectorAll<HTMLInputElement>("[name^=price]");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type == "checkbox") items[i].checked = false;
      }
      var eventData = document.querySelector<HTMLInputElement>("[name^=price]")
        .name;
      this.addprop1(eventData);
    }
  }
  toggleBrands() {
    this.showBrands = !this.showBrands;
  }

  toggleCategories() {
    this.showCategories = !this.showCategories;
  }

  togglePrices() {
    this.showPrices = !this.showPrices;
  }
}
