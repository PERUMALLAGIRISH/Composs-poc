import { Component, OnInit } from "@angular/core";
import { Iproduct, Ireview } from "../product";
import { NgbRatingConfig } from "@ng-bootstrap/ng-bootstrap";
import { Category } from "../../navigation/category";
import { CategoriesService } from "../../navigation/categories.service";
import { Slider } from "../../home/slider";
import { ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from "ngx-gallery";
import { ToastrService } from "../../../../node_modules/ngx-toastr";
import { ProductResponse } from 'src/app/shared/models/productResponse';
import { ProductService } from 'src/app/shared/services/product.service';
import { CartService } from 'src/app/shared/services/cart.service';
import { CartResponse } from 'src/app/shared/models/cartResponse';
import { User } from 'src/app/shared/models/user';

@Component({
  selector: "app-product-detail",
  templateUrl: "./product-detail.component.html",
  styleUrls: ["./product-detail.component.css"]
})
export class ProductDetailComponent implements OnInit {
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  addToCartForm: FormGroup;
  submitted = false;
  // qty: number = 1;
  // model: any = {};
  // products: Iproduct[];
  // categories: Category[];
  // categorycurrentProduct = {};
  stars: number;
  mainImage: string;
  // prdName: any;
  // prdSku: any;
  // prdPrice: number;
  baseImages = [];
  arrayImages = [];
  // currentProduct = {};
  // pId;
  // cId;
  // categoryName: any;
  // recentPrd: any = [];

  productResponse: ProductResponse;
  productId: string;
  cartResponse: CartResponse;
  selectedColor: string;
  selectedMemorySize: string;
  selectedVariant: string;
  user: User;

  // firstNameToUpperCase(value: string) {
  //   if (value.length > 0)
  //     this.model.Name = value.charAt(0).toUpperCase() + value.slice(1);
  //   else this.model.Name = value;
  // }

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private Ratingconfig: NgbRatingConfig,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private CategoryService: CategoriesService,
    public toastr: ToastrService
  ) {
    Ratingconfig.max = 5;
    Ratingconfig.readonly = true;
    this.productId = localStorage.getItem("productId");
    this.stars = 5;
  }


  onColorSelected(selectedColor: string): void {
    this.baseImages=[];
    this.arrayImages=[];
    this.mainImage="";
    this.selectedColor = selectedColor;
    console.log(this.selectedColor);
    for(var i=0; i<this.productResponse.data.colors.length; i++) {
      if(this.productResponse.data.colors[i].color.colorId == this.selectedColor) {
        for(var j=0; j<this.productResponse.data.colors[i].medias.length; j++){
          if(this.productResponse.data.colors[i].medias[j].mediaSequenceId == 1){
            this.mainImage = this.productResponse.data.colors[i].medias[j].url;
          }
          this.baseImages[j]=this.productResponse.data.colors[i].medias[j].url;
        }
      }  
    }
    //for image slider generate array
    this.baseImages.forEach(image => {
      var sliderArray = {
        small: image,
        medium: image,
        big: image
      };
      this.arrayImages.push(sliderArray);
    });
    this.galleryImages = this.arrayImages;
  }
  onMemorySelected(selectedMemorySize: string): void {
    this.selectedMemorySize = selectedMemorySize;
    console.log(this.selectedMemorySize);
  }
  onVariantSelected(color:string, memorySize: string): void {
    this.selectedVariant = this.productResponse.data.productId + "_" + color + "_" + memorySize;
    console.log(this.selectedVariant);
  }

getProduct() {
  this.productService.getProduct("P1")
  .subscribe(
    data => {
      this.productResponse = data;
      console.log(this.productResponse);
      for(var i=0; i<this.productResponse.data.memories.length; i++) {
        if(this.productResponse.data.memories[i].sequenceNumber == 2) {
          this.selectedMemorySize=this.productResponse.data.memories[i].memorySizeValue;
        }
      }
      for(var i=0; i<this.productResponse.data.colors.length; i++) {
        if(this.productResponse.data.colors[i].color.sequenceNumber == 1) {
          this.selectedColor=this.productResponse.data.colors[i].color.colorId;
          for(var j=0; j<this.productResponse.data.colors[i].medias.length; j++){
            if(this.productResponse.data.colors[i].medias[j].mediaSequenceId == 1){
              this.mainImage = this.productResponse.data.colors[i].medias[j].url;
              console.log(this.mainImage);
            }
            this.baseImages[j]=this.productResponse.data.colors[i].medias[j].url;
            console.log(this.productResponse.data.colors[i].medias[j].url);
          }    
        }
      }
      this.selectedVariant = this.productResponse.data.productId + "_" + this.selectedColor + "_" + this.selectedMemorySize;     
      this.baseImages.forEach(image => {
        var sliderArray = {
          small: image,
          medium: image,
          big: image
        };
        this.arrayImages.push(sliderArray);
      });
      this.galleryImages = this.arrayImages; 
    }
  )
}

get f() {
  return this.addToCartForm.controls;
}

buyNow() {
  this.submitted = true;
  if(!this.user){
    document.getElementById("signIn").click();
    return;
  }
    //stop here if form is invalid
    if (this.addToCartForm.invalid) {
      return;
    }
    var quantity = this.addToCartForm.value.quantity;
    var totalItems="0";
    this.cartService.addToCart(this.selectedVariant,quantity)
    .subscribe(
      data => {
        this.cartResponse = data;
        console.log(this.cartResponse);
        if (!this.cartResponse) {
          var supNode = document.createElement("span");
          supNode.classList.add("badge");
          supNode.classList.add("badge-notify");
          var textnode = document.createTextNode(totalItems);
          supNode.appendChild(textnode);
          document.getElementById("miniCart").appendChild(supNode);
        } else if (this.cartResponse.data.totalItems == 0) {
          var supNode = document.createElement("span");
          supNode.classList.add("badge");
          supNode.classList.add("badge-notify");
          var textnode = document.createTextNode(totalItems);
          supNode.appendChild(textnode);
          document.getElementById("miniCart").appendChild(supNode);
        } else {
          console.log((this.cartResponse.data.totalItems).toString());
          document.querySelector("#miniCart span").innerHTML = (this.cartResponse.data.totalItems).toString();
        }
        this.router.navigate(['checkout']);
      }
    )   
}

addToCart() {
  this.submitted = true;

  if(!this.user){
    document.getElementById("signIn").click();
    return;
  }
  //stop here if form is invalid
  if (this.addToCartForm.invalid) {
    return;
  }
  var quantity = this.addToCartForm.value.quantity;
  var totalItems="0";
  this.cartService.addToCart(this.selectedVariant,quantity)
  .subscribe(
    data => {
      this.cartResponse = data;
      console.log(this.cartResponse);
      if (!this.cartResponse) {
        var supNode = document.createElement("span");
        supNode.classList.add("badge");
        supNode.classList.add("badge-notify");
        var textnode = document.createTextNode(totalItems);
        supNode.appendChild(textnode);
        document.getElementById("miniCart").appendChild(supNode);
      } else if (this.cartResponse.data.totalItems == 0) {
        var supNode = document.createElement("span");
        supNode.classList.add("badge");
        supNode.classList.add("badge-notify");
        var textnode = document.createTextNode(totalItems);
        supNode.appendChild(textnode);
        document.getElementById("miniCart").appendChild(supNode);
      } else {
        console.log((this.cartResponse.data.totalItems).toString());
        document.querySelector("#miniCart span").innerHTML = (this.cartResponse.data.totalItems).toString();
      }
    }
  )  
}

ngOnInit(): void {
  this.addToCartForm = this.formBuilder.group({
    quantity: [1, Validators.required]
  });
  this.getProduct();  

    //for image slider configuration
    this.galleryOptions = [
      {
        width: "80%",
        height: "700px",
        thumbnailsColumns: 4,
        imageDescription: true,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 800,
        width: "90%",
        height: "800px",
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      // max-width 400
      {
        breakpoint: 400,
        width: "100%",
        height: "600px",
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      { breakpoint: 300, width: "100%", height: "400px", thumbnailsColumns: 2 }
    ];
  }

  toggleSign(arg): void {
    let id = document.getElementById(arg);
    var src = id.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    id.setAttribute("src", src);
  }

  readMorebtn() {
    var text = document.getElementById("more");
    var text1 = document.getElementById("read");
    if (text.style.display == "none") {
      text1.innerHTML = "Read less";
      text.style.display = "block";
    } else {
      text1.innerHTML = "Read more";
      text.style.display = "none";
    }
  }
  

  // buynow() {
  //   this.submitted = true;

  //   //stop here if form is invalid
  //   if (this.addToCartForm.invalid) {
  //     return;
  //   }



    

    // if (localStorage.getItem("logedUser")) {
    //   var quantity = parseInt(this.addToCartForm.value.quantity);
    //   var cartData = [];

    //   var subTotal: number;
    //   var grandTotal: number;
    //   var totalQuantity;
    //   var shippingCharge: number;
    //   var shippingMethod;
    //   var isPush: boolean = false;
    //   var isMaxQty: boolean = false;
    //   var maxQty: number = 5;
    //   var updateQty: number;
    //   var currentUser = localStorage.getItem("logedUserEmail");
    //   var UserData = JSON.parse(localStorage.getItem(currentUser));
    //   localStorage.removeItem(currentUser);

    //   if (UserData[0]["cartData"]) {
    //     cartData = UserData[0]["cartData"]["productData"];
    //     isPush = true;
    //     cartData.forEach(product => {
    //       if (product.productId == this.pId) {
    //         updateQty = product.quantity + qty;
    //         if (
    //           updateQty > 0 &&
    //           updateQty <= maxQty &&
    //           product.isDeleted == true
    //         ) {
    //           product.quantity = qty;
    //           product.price = this.prdPrice * product.quantity;
    //           product.isDeleted = false;
    //         } else if (updateQty > 0 && updateQty <= maxQty) {
    //           product.quantity += qty;
    //           product.price = this.prdPrice * product.quantity;
    //           product.isDeleted = false;
    //         } else {
    //           isMaxQty = true;
    //           var oldCart = UserData[0]["cartData"];
    //           subTotal = oldCart["subTotal"];
    //           grandTotal = oldCart["grandTotal"];
    //           totalQuantity = parseInt(oldCart["totalQuantity"]);
    //           shippingCharge = oldCart["shippingCharge"];
    //           shippingMethod = oldCart["shippingMethod"];
    //           this.toastr.error(
    //             "Cann't add more than 5 Quantity and less than 1"
    //           );
    //         }
    //         isPush = false;
    //       }
    //     });
    //     if (!isMaxQty) {
    //       var oldCart = UserData[0]["cartData"];
    //       subTotal = oldCart["subTotal"] + this.prdPrice * qty;
    //       grandTotal = oldCart["grandTotal"] + this.prdPrice * qty;
    //       totalQuantity = oldCart["totalQuantity"] + qty;
    //       shippingCharge = oldCart["shippingCharge"];
    //       shippingMethod = oldCart["shippingMethod"];
    //     }
    //   } else {
    //     subTotal = this.prdPrice * qty;
    //     grandTotal = this.prdPrice * qty + 0;
    //     totalQuantity = qty;
    //     shippingCharge = 0;
    //     shippingMethod = "free";
    //     isPush = true;
    //   }
    //   if (isPush) {
    //     cartData.push({
    //       productId: this.pId,
    //       name: this.prdName,
    //       sku: this.prdSku,
    //       quantity: qty,
    //       price: this.prdPrice * qty,
    //       productPrice: this.prdPrice,
    //       image: this.mainImage,
    //       isDeleted: false
    //     });
    //   }

    //   var cart = {
    //     productData: cartData,
    //     subTotal: subTotal,
    //     grandTotal: grandTotal,
    //     totalQuantity: totalQuantity,
    //     shippingCharge: shippingCharge,
    //     shippingMethod: shippingMethod
    //   };
    //   //this. = totalQuantity;
    //   if (!UserData[0]["cartData"]) {
    //     var supNode = document.createElement("span");
    //     supNode.classList.add("badge");
    //     supNode.classList.add("badge-notify");
    //     var textnode = document.createTextNode(totalQuantity);
    //     supNode.appendChild(textnode);
    //     document.getElementById("miniCart").appendChild(supNode);
    //   } else if (UserData[0]["cartData"].totalQuantity == 0) {
    //     var supNode = document.createElement("span");
    //     supNode.classList.add("badge");
    //     supNode.classList.add("badge-notify");
    //     var textnode = document.createTextNode(totalQuantity);
    //     supNode.appendChild(textnode);
    //     document.getElementById("miniCart").appendChild(supNode);
    //   } else {
    //     document.querySelector("#miniCart span").innerHTML = totalQuantity;
    //   }

    //   UserData[0]["cartData"] = cart;
    //   localStorage.setItem(currentUser, JSON.stringify(UserData));
    //   this.router.navigate(["/cart"]);
    // } else {
    //   let element = document.getElementById("signIn");
    //   element.click();
    // }
  // }
  // addTocart() {
  //   this.submitted = true;

  //   //stop here if form is invalid
  //   if (this.addToCartForm.invalid) {
  //     return;
  //   }

  //   if (localStorage.getItem("logedUser")) {
  //     var qty = parseInt(this.addToCartForm.value.quantity);
  //     var cartData = [];
  //     var subTotal: number;
  //     var grandTotal: number;
  //     var totalQuantity;
  //     var shippingCharge: number;
  //     var shippingMethod;
  //     var maxQty: number = 5;
  //     var isPush: boolean = false;
  //     var isMaxQty: boolean = false;
  //     var updateQty: number;
  //     var currentUser = localStorage.getItem("logedUserEmail");
  //     var UserData = JSON.parse(localStorage.getItem(currentUser));
  //     localStorage.removeItem(currentUser);

  //     if (UserData[0]["cartData"]) {
  //       cartData = UserData[0]["cartData"]["productData"];
  //       isPush = true;

  //       cartData.forEach(product => {
  //         if (product.productId == this.pId) {
  //           updateQty = product.quantity + qty;
  //           if (
  //             updateQty > 0 &&
  //             updateQty <= maxQty &&
  //             product.isDeleted == true
  //           ) {
  //             product.quantity = qty;
  //             product.price = this.prdPrice * product.quantity;
  //             product.isDeleted = false;
  //           } else if (updateQty > 0 && updateQty <= maxQty) {
  //             product.quantity += qty;
  //             product.price = this.prdPrice * product.quantity;
  //             product.isDeleted = false;
  //           } else {
  //             isMaxQty = true;
  //             var oldCart = UserData[0]["cartData"];
  //             subTotal = oldCart["subTotal"];
  //             grandTotal = oldCart["grandTotal"];
  //             totalQuantity = parseInt(oldCart["totalQuantity"]);
  //             shippingCharge = oldCart["shippingCharge"];
  //             shippingMethod = oldCart["shippingMethod"];
  //             this.toastr.error(
  //               "Cann't add more than 5 Quantity and less than 1"
  //             );
  //           }
  //           isPush = false;
  //         }
  //       });
  //       if (!isMaxQty) {
  //         var oldCart = UserData[0]["cartData"];
  //         subTotal = oldCart["subTotal"] + this.prdPrice * qty;
  //         grandTotal = oldCart["grandTotal"] + this.prdPrice * qty;
  //         totalQuantity = parseInt(oldCart["totalQuantity"]) + qty;
  //         shippingCharge = oldCart["shippingCharge"];
  //         shippingMethod = oldCart["shippingMethod"];
  //       }
  //     } else {
  //       subTotal = this.prdPrice * qty;
  //       grandTotal = this.prdPrice * qty + 0;
  //       totalQuantity = qty;
  //       shippingCharge = 0;
  //       shippingMethod = "free";
  //       isPush = true;
  //     }
  //     if (isPush) {
  //       cartData.push({
  //         productId: this.pId,
  //         name: this.prdName,
  //         sku: this.prdSku,
  //         quantity: qty,
  //         price: this.prdPrice,
  //         productPrice: this.prdPrice,
  //         image: this.mainImage,
  //         isDeleted: false
  //       });
  //     }

  //     var cart = {
  //       productData: cartData,
  //       subTotal: subTotal,
  //       grandTotal: grandTotal,
  //       totalQuantity: totalQuantity,
  //       shippingCharge: shippingCharge,
  //       shippingMethod: shippingMethod
  //     };
  //     //console.log(cart);

  //     if (!UserData[0]["cartData"]) {
  //       var supNode = document.createElement("span");
  //       supNode.classList.add("badge");
  //       supNode.classList.add("badge-notify");
  //       var textnode = document.createTextNode(totalQuantity);
  //       supNode.appendChild(textnode);
  //       document.getElementById("miniCart").appendChild(supNode);
  //     } else if (UserData[0]["cartData"].totalQuantity == 0) {
  //       var supNode = document.createElement("span");
  //       supNode.classList.add("badge");
  //       supNode.classList.add("badge-notify");
  //       var textnode = document.createTextNode(totalQuantity);
  //       supNode.appendChild(textnode);
  //       document.getElementById("miniCart").appendChild(supNode);
  //     } else {
  //       document.querySelector("#miniCart span").innerHTML = totalQuantity;
  //     }
  //     UserData[0]["cartData"] = cart;
  //     localStorage.setItem(currentUser, JSON.stringify(UserData));
  //     if (!isMaxQty) {
  //       this.toastr.success("You have successfully added the item to cart.");
  //     }
  //   } else {
  //     let element = document.getElementById("signIn");
  //     element.click();
  //   }
  // }

  // triggerClick() {
  //   let element = document.getElementById("signIn");
  //   element.click();
  // }
  
}
