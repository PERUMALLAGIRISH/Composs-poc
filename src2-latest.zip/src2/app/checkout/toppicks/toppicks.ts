export interface Toppicks {
  productId: number;
  sku: string;
  quantity: number;
  price: number;
  productPrice: number;
  name: string;
  image: string;
  subTotal: number;
  grandTotal: number;
  totalQuantity: number;
  shippingMethod: string;
  shippingCharge: number;
}
