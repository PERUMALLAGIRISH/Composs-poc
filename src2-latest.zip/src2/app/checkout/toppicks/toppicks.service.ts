import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: "root"
})
export class ToppicksService {
  private productUrl = "./assets/json/relatedproducts.json";
  constructor(private http: HttpClient) {}

  getRelatedProducts() {
    return this.http.get(this.productUrl);
  }
}
