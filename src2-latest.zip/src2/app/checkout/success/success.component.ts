import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { OrderService } from 'src/app/shared/services/order.service';
import { OrderResponse } from 'src/app/shared/models/orderResponse';

@Component({
  selector: "app-success",
  templateUrl: "./success.component.html",
  styleUrls: ["./success.component.css"]
})
export class SuccessComponent implements OnInit {
  [x: string]: any;
  orderId: string;
  status: string;
  date: any;
  total: any;
  user = localStorage.getItem("user");
  orderResponse: OrderResponse;
  constructor(
    private router: Router,
    private orderService: OrderService
  ) {
    this.orderId = (localStorage.getItem("orderId"))
  }


  getOrderDetails() {
    this.orderService.getOrderDetails()
    .subscribe(
      data => {
        this.orderResponse = data;
        console.log(this.orderResponse);
        var item = document.querySelector("#miniCart span");
        item.parentNode.removeChild(item);
      }
    )
  }

  ngOnInit() {
    document.getElementById("navbar").style.display = "none";
    if(this.orderId){
      this.getOrderDetails();
    }
    
    // var orderDetails = JSON.parse(localStorage.getItem("lastOrder"));
    // if (this.orderId) {
      // this.orderId = orderDetails.orderInfo["orderId"];
      // this.status = "Ready";
      // this.date = orderDetails.orderInfo["datePlace"];
      // this.total = orderDetails.orderInfo["grantTotal"];
      // this.subTotal = orderDetails.orderInfo["subTotal"];
      // this.shipAmount = orderDetails.orderInfo["shipAmount"];
      // this.paymentNo = orderDetails.orderInfo["payment"];
      // this.shipMethodname = orderDetails.orderInfo["shipMethodname"];
      // this.productData = orderDetails.productData;
      // this.addr = orderDetails.addr;
    // } else {
    //   this.router.navigate(["/"]);
    // }
    // localStorage.removeItem("lastOrder");
    // let updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
    // updatedCartall[0].cartData = "";
    

    // localStorage.setItem(this.currentUser, JSON.stringify(updatedCartall));
  }
}
