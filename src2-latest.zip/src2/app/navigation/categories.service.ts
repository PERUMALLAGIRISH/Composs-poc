import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Category } from "./category";
import { Observable } from "../../../node_modules/rxjs";

@Injectable({
  providedIn: "root"
})
export class CategoriesService {
  private cartUrl = "./assets/json/categories.json";
  constructor(private httpService: HttpClient) {}

  getCategories(): Observable<Category[]> {
    return this.httpService.get<Category[]>(this.cartUrl);
  }
}
