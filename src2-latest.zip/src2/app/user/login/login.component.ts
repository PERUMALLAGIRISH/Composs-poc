import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";
import { UserService } from 'src/app/shared/services/user.service';
import { LoginResponse } from 'src/app/shared/models/LoginResponse';


@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  loginResponse: LoginResponse;
  error: boolean;
  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router,
    private modalService: NgbModal,
    private userService: UserService
  ) {}

  ngOnInit() {
    if (localStorage.getItem("user")) {
      this.router.navigate(["/"]);
    }
    this.loginForm = this.formBuilder.group({
      userId: ["", Validators.required],
      password: ["", Validators.required],
      signInCheck: [""]
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  login() {
    this.error = false;
    this.submitted = true;
    //stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    var userId = this.loginForm.value.userId;
    var password = this.loginForm.value.password;
    console.log(userId + " " + password);
    this.userService.login(userId,password)
    .subscribe(
      data => {
        this.loginResponse = data;
        console.log(this.loginResponse);
        if(this.loginResponse.technicalError){
          this.error = true;
          return;
        }
        console.log("signing in");
        localStorage.setItem("userId",this.loginResponse.data.userId);
        localStorage.setItem("user", JSON.stringify(this.loginResponse));
        document.getElementById("loginClose").click();
        location.reload();
        
      }   
    )
  }
}
