import { Component, OnInit, ElementRef } from "@angular/core";
import { trigger, state, style, animate, transition } from "@angular/animations";
import { DeviceDetectorService } from "ngx-device-detector";
import { FormGroup, FormBuilder, Validators } from "../../../node_modules/@angular/forms";
import { Router } from "../../../node_modules/@angular/router";

import { CategoriesService } from "../navigation/categories.service";
import { Category } from "../navigation/category";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
  animations: [
    trigger("slideMenu", [
      state(
        "open",
        style({
          transform: "translateX(0%)"
        })
      ),
      state(
        "close",
        style({
          transform: "translateX(-105%)"
        })
      ),
      transition("open=>close", animate("300ms")),
      transition("close=>open", animate("200ms"))
    ]),
    trigger("FadeAnimation", [
      state(
        "in",
        style({
          opacity: "1",
          display: "block"
        })
      ),
      state(
        "out",
        style({
          opacity: "0",
          display: "none"
        })
      ),
      transition("in=>out", animate("500ms")),
      transition("out=>in", animate("500ms"))
    ]),
    trigger("changeDivSize", [
      state(
        "initial",
        style({
          opacity: "0",
          display: "none"
        })
      ),
      state(
        "final",
        style({
          opacity: "1",
          display: "block"
        })
      ),
      transition("initial=>final", animate("500ms")),
      transition("final=>initial", animate("200ms"))
    ])
  ],
  host: {
    "(document:click)": "onClick($event)"
  }
})
export class HeaderComponent implements OnInit {
  userName: any;
  searchForm: FormGroup;
  submitted: boolean = false;
  show: boolean = false;
  loggedUser: boolean = false;
  currentUser: string;
  currentUserEmail: string;
  userDetails: any;
  cartAll: any;
  compareProduct: any;
  isCmprPrd: boolean;
  cmprCount: number;
  totalQty: number = 0;
  isCartQty: boolean = false;
  currentState: string = "initial";
  menuState: string = "close";
  fadeState: string = "out";
  icon: string;
  categoriesList: Category[];
  errorMessage: any;
  isMobile: boolean = false;
  menuClicked: boolean = true;
  showCartImage: boolean = false;
  showUserImage: boolean = false;
  showSearchImage: boolean = false;
  clickUserImage: boolean = false;
  searchIcon: string = "assets/icons/searchIconNormal.svg";
  cartIcon: string = "assets/icons/cartIconNormal.svg";
  profileIcon: string = "assets/icons/profileIconNormal.svg";
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private deviceService: DeviceDetectorService,
    private categoriesService: CategoriesService
  ) { }

  ngOnInit() {
    this.isMobile = this.deviceService.isMobile();
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
      },
      error => (this.errorMessage = <any>error)
    );
    if (localStorage["loggedUser"] == "true") {
      this.showUserImage = true;
    }
    if (localStorage["loggedUser"] == "true") {
      this.loggedUser = !this.loggedUser;
      this.currentUser = localStorage.getItem("loggedUserEmail");
      this.userName = JSON.parse(localStorage.getItem(this.currentUser))[0];
      this.userDetails = JSON.parse(localStorage.getItem(this.currentUser));
      this.compareProduct = this.userDetails[0].comparePrd;
      if (this.compareProduct && this.compareProduct.length > 0) {
        this.isCmprPrd = true;
        this.cmprCount = this.compareProduct.length;
      } else {
        this.isCmprPrd = false;
      }
      this.cartAll = this.userDetails[0].cartData;
      if (this.cartAll) {
        this.totalQty = this.cartAll.totalQuantity;
      } else {
        this.totalQty = 0;
      }
      if (this.totalQty > 0) {
        this.isCartQty = true;
      } else {
        this.isCartQty = false;
      }
    }
    this.searchForm = this.formBuilder.group({
      search: ["", Validators.required]
    });
    this.icon = "fa-chevron-down";
    document.getElementById("searchClose").style.display = "block";
  }

  showMewnu() {
    this.menuState = "open";
    this.fadeState = "in";
  }

  closeMenu() {
    this.menuState = "close";
    this.fadeState = "out";
  }

  cnangeIcon(event, i) {
    if (this.menuClicked == true) {
      event.target.classList.remove("fa-chevron-down");
      event.target.classList.add("fa-chevron-up");
      document.getElementById("mobile-h" + i).style.color = "#0088FF";
      event.target.style.color = "#0088FF";
      this.menuClicked = false;
    } else {
      event.target.classList.remove("fa-chevron-up");
      event.target.classList.add("fa-chevron-down");
      document.getElementById("mobile-h" + i).style.color = "gray";
      event.target.style.color = "gray";
      this.menuClicked = true;
    }
  }

  // Header Search icon hover functionality
  changeSearchicon(state) {
    if (this.searchIcon != "assets/icons/searchBarCloseIcon.svg") {
      if (state == 1) {
        this.searchIcon = "assets/icons/searchIconSelected.svg";
      } else {
        this.searchIcon = "assets/icons/searchIconNormal.svg";
      }
    }
  }

  // Header cart icon hover functionality
  changeCarticon(state) {
    if (state == 1) {
      this.cartIcon = "assets/icons/cartIconSelected.svg";
    } else {
      this.cartIcon = "assets/icons/cartIconNormal.svg";
    }
  }

  changeUsericon(state) {
    if (state == 1) {
      this.profileIcon = "assets/icons/profileIconSelected.svg";
    } else {
      this.profileIcon = "assets/icons/profileIconNormal.svg";
    }
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.searchForm.controls;
  }

  // Header Profile toggle functionality
  toggle() {
    this.profileIcon = "assets/icons/profileIconSelected.svg";
    if (!localStorage["loggedUser"]) {
      this.showUserImage = !this.showUserImage;
    }
    this.show = !this.show;
  }

  // SearchBox open and close functionality
  changeState(event) {
    if (this.currentState == "initial") {
      this.searchIcon = "assets/icons/searchBarCloseIcon.svg";
      this.currentState = "final";
    } else {
      this.searchIcon = "assets/icons/searchIconNormal.svg";
      this.currentState = "initial";
    }
  }

  onClick(event) {
    if (event.target.id != "dropdownMenuLink" && this.show) {
      this.show = !this.show;
      if (!localStorage["loggedUser"]) {
        this.showUserImage = !this.showUserImage;
      }
    }
  }

  // Signout functionality 
  signOut() {
    localStorage.removeItem("loggedUser");
    localStorage.removeItem("loggedUserEmail");
    this.router.navigate(["/"]);
    location.reload();
  }

  // Search functionality 
  onSearch() {
    this.submitted = true;
    if (this.searchForm.invalid) {
      return;
    }
    let value = this.searchForm.value.search;
    this.router.navigate(["/search/" + value]);
  }

  toggleSearchImage() {
    this.showSearchImage = !this.showSearchImage;
  }
}
