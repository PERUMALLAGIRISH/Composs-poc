import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { PageChangedEvent } from "ngx-bootstrap/pagination";
import { ToastrService } from "ngx-toastr";

import { IProduct } from "../orderdetails";

@Component({
  selector: "app-userinformation",
  templateUrl: "./userinformation.component.html",
  styleUrls: ["./userinformation.component.css"]
})
export class UserinformationComponent implements OnInit {
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private route: ActivatedRoute
  ) {
    this.filteredProducts = this.orderdetails;
    this.listFilter = "";
  }
  totalItems: number;
  id: number;
  addressId: number;
  isLoggedIn: boolean;
  submitted: boolean = false;
  loggedIn: boolean = false;
  submittedAddress: boolean = false;
  msg: string = null;
  userInfoType: string;
  currentUserEmail: string;
  _listFilter: string;
  userName: string;
  orderdetails: IProduct[];
  data: IProduct[] = [];
  items: IProduct[];
  formdata = [];
  filteredProducts: IProduct[];
  products: IProduct[] = [];
  orderDetail: any;
  accountDetailsFlag: any;
  manageDetailsFlag: any;
  addressDetailsFlag: any;
  orderDetailsFlag: any;
  viewDetailsFlag: any;
  detailsservice: any;
  updatedCartall: any;
  updatedCartList: any;
  currentUser: any;
  addresses: any;
  editAddress: any;
  changePasswordForm: FormGroup;
  addressForm: FormGroup;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  numberonlyZipCode = "^[0-9]{6,6}$";
  contentArray = new Array().fill("");
  userEmail = localStorage["loggedUserEmail"];

  // Get filter data
  get listFilter(): string {
    return this._listFilter;
  }

  // Set filter data
  set listFilter(value: string) {
    this._listFilter = value;
    this.data = this.listFilter
      ? this.performFilter(this.listFilter)
      : this.orderdetails;
  }

  ngOnInit() {
    document.getElementById("navbar").style.display = "flex";
    this.route.params.subscribe(params => {
      this.userInfoType = params["id"];
      this.accountDetailsFlag =
        this.userInfoType == "AccountDetails" ? "1" : " 0";
      this.manageDetailsFlag =
        this.userInfoType == "ManagePassword" ? "1" : " 0";
      this.addressDetailsFlag = this.userInfoType == "AddressBook" ? "1" : " 0";
      this.orderDetailsFlag = this.userInfoType == "OrderHistory" ? "1" : " 0";
      this.submitted = this.userInfoType == "ManagePassword" ? false : true;
      this.submittedAddress = this.userInfoType == "AddressBook" ? false : true;
    });

    /*Fetch Local Storage user values*/
    if (!localStorage.getItem("loggedUser")) {
      this.router.navigateByUrl("/");
    }
    this.currentUserEmail = localStorage.getItem("loggedUserEmail");
    this.currentUser = JSON.parse(
      localStorage.getItem(this.currentUserEmail)
    )[0];

    this.changePasswordForm = this.formBuilder.group(
      {
        oldPassword: ["", [Validators.required, Validators.minLength(6)]],
        newPassword: ["", [Validators.required, Validators.minLength(6)]],
        confirmPassword: ["", Validators.required]
      },
      {
        validator: this.matchValidator("newPassword", "confirmPassword")
      }
    );

    this.addressForm = this.formBuilder.group({
      firstName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      lastName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      PhoneNumber: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyPhone)]
      ],
      cityName: ["", Validators.required],
      stateName: ["", Validators.required],
      streetName: ["", Validators.required],
      countryName: ["", Validators.required],
      zipCode: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyZipCode)]
      ]
    });

    this.addresses = JSON.parse(localStorage[this.userEmail]);
    this.addresses = this.addresses.filter(function (el) {
      return el != null;
    });

    this.userName = this.addresses[0].firstName;
    this.orderdetails = this.currentUser["orderData"]["orders"];
    this.contentArray = this.orderdetails;
    this.orderdetails = this.contentArray.slice(0, 4);
  }

  // Geting form data for validacation
  get getFormValue() {
    if (this.userInfoType == "ManagePassword" || this.manageDetailsFlag == 1) {
      return this.changePasswordForm.controls;
    } else if (
      this.userInfoType == "AddressBook" ||
      this.addressDetailsFlag == 1
    ) {
      return this.addressForm.controls;
    }
  }

  // Match password & conform password is same
  matchValidator(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        return;
      }
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ match: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  // Navigate to customer info
  redirecttype(type) {
    this.submitted = type == "ManagePassword" ? false : true;
    this.submittedAddress = type == "AddressBook" ? false : true;
    if (type == "OrderHistory") {
      this.orderDetailsFlag = 1;
    }
    this.viewDetailsFlag = 0;
    this.router.navigate(["/customer", type]);
  }

  // Change user password info
  changePassword() {
    this.submitted = true;
    this.loggedIn = true;
    if (this.changePasswordForm.invalid) {
      return;
    }
    let oldPassword = JSON.parse(localStorage.getItem(this.userEmail))[0]
      .password;
    if (oldPassword != this.changePasswordForm.value.oldPassword) {
      this.toastr.error("Old password is not correct.");
    } else {
      let customerAll = JSON.parse(localStorage.getItem(this.userEmail));
      let usercustomerAll = JSON.parse(localStorage.getItem("userDatas"));
      customerAll[0].password = this.changePasswordForm.value.newPassword;
      customerAll[0].confirmPassword = this.changePasswordForm.value.newPassword;
      usercustomerAll[0].password = this.changePasswordForm.value.newPassword;
      usercustomerAll[0].confirmPassword = this.changePasswordForm.value.newPassword;
      localStorage.setItem(this.userEmail, JSON.stringify(customerAll));
      localStorage.setItem("userDatas", JSON.stringify(usercustomerAll));
      this.toastr.success("Password changed successfully.");
    }
  }

  // Edit user address info
  editUserAddress(addressId) {
    this.editAddress = this.addresses[addressId];
    this.addressForm.setValue(this.editAddress);
    this.addressId = addressId;
  }

  // Delete user address info
  deleteUserAddress(value) {
    var datas = localStorage[this.userEmail];
    datas = JSON.parse(datas);
    datas[value] = [];
    datas.splice(value, 1);
    localStorage[this.userEmail] = JSON.stringify(datas);
    this.addresses = JSON.parse(localStorage[this.userEmail]);
  }

  // Save use Address info Add and Update
  saveUserAddress(value) {
    this.submittedAddress = true;
    //stop here if form is invalid
    if (this.addressForm.invalid) {
      return;
    }
    var element = document.getElementById("closeAddress");
    element.click();

    if (value) {
      var datas = localStorage[this.userEmail];
      datas = JSON.parse(datas);
      datas[value] = this.addressForm.value;
      localStorage[this.userEmail] = JSON.stringify(datas);
      this.addresses = JSON.parse(localStorage[this.userEmail]);
      this.toastr.success("You have successfully updated the address.");
    } else {
      var datas = localStorage[this.userEmail];
      //check local storage is empty
      if (datas !== undefined) {
        datas = JSON.parse(datas);
        datas.push(this.addressForm.value);
        localStorage[this.userEmail] = JSON.stringify(datas);
      } else {
        this.formdata.push(this.addressForm.value);
        localStorage[this.userEmail] = JSON.stringify(this.formdata);
      }
      this.addresses = JSON.parse(localStorage[this.userEmail]);
      this.toastr.success("You have successfully added new address.");
    }
  }

  // Filter Data info
  performFilter(filterBy: string): IProduct[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.orderdetails.filter(
      (product: IProduct) =>
        product.DatePlaced.toLocaleLowerCase().indexOf(filterBy) !== -1
    );
  }

  // pagination for order list info
  pageChanged(event: PageChangedEvent): void {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.orderdetails = this.contentArray.slice(startItem, endItem);
  }

  // view order info
  viewOrder(type, value) {
    this.orderDetail = this.currentUser["orderData"]["orders"][value];
    this.viewDetailsFlag = 1;
    this.orderDetailsFlag = 0;
  }
}
