import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Gallery, GalleryRef } from "@ngx-gallery/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NgbRatingConfig } from "@ng-bootstrap/ng-bootstrap";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";

import { Category } from "../../navigation/category";
import { CategoriesService } from "../../navigation/categories.service";
import { Iproduct, Ireview } from "../product";
import { ProductserviceService } from "../../services/product.services";
import { Slider } from "../../home/slider";

@Component({
  selector: "app-product-detail",
  templateUrl: "./product-detail.component.html",
  styleUrls: ["./product-detail.component.css"]
})

export class ProductDetailComponent implements OnInit {
  addCart: FormGroup;
  submitted = false;
  qty: number = 1;
  model: any = {};
  products: Iproduct[];
  categories: Category[];
  categorycurrentProduct = {};
  stars: Ireview[];
  mainImage: string;
  prdName: any;
  prdSku: any;
  prdPrice: number;
  arrayImages = [];
  currentProduct = {};
  pId: any;
  cId: any;
  categoryName: any;
  recentPrd: any = [];
  galleryId: string = "mixedExample";
  baseImages: any;
  carouselImages: any;
  qtyValue: number = 1;
  currentUser: string;
  loggedUser: boolean = false;
  userDetails: any;
  username: any;
  compareProduct: any;
  isCmprPrd: boolean;
  cmprCount: number;

  firstNameToUpperCase(value: string) {
    if (value.length > 0)
      this.model.Name = value.charAt(0).toUpperCase() + value.slice(1);
    else this.model.Name = value;
  }

  constructor(
    private Productservice: ProductserviceService,
    private Ratingconfig: NgbRatingConfig,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private CategoryService: CategoriesService,
    public toastr: ToastrService,
    private gallery: Gallery
  ) {
    Ratingconfig.max = 5;
    Ratingconfig.readonly = true;
  }

  ngOnInit() {
    const galleryRef: GalleryRef = this.gallery.ref(this.galleryId);
    this.pId = this.route.snapshot.paramMap.get("id");
    this.addCart = this.formBuilder.group({
      qty: [1, Validators.required]
    });
    this.Productservice.getProducts().subscribe(data => {
      this.products = data as Iproduct[];
      this.products.forEach(product => {
        if (product["productId"] == this.pId) {
          this.currentProduct = product;
          this.stars = product["reviews"];
          this.mainImage = product["baseImages"][0];
          this.baseImages = product["baseImages"];
          this.carouselImages = product["carouselImages"];
          this.prdName = product["name"];
          this.prdSku = product["sku"];
          this.prdPrice = product["price"];
          //get Category Id
          this.cId = product["category_id"];
          this.CategoryService.getCategories().subscribe(data => {
            this.categoryName = data.filter(
              category => category.categoryId == this.cId
            );
            this.categoryName = this.categoryName[0].name;
          });

          this.carouselImages.forEach(carouselImage => {
            if (carouselImage.type == "image")
              carouselImage.image =
                "../../assets/images/product/" + carouselImage.image;
            if (carouselImage.type == "video")
              carouselImage.image =
                "../../assets/images/video/" + carouselImage.image;
          });

          for (let i = 0; i < this.carouselImages.length; i++) {
            if (this.carouselImages[i].type == "image") {
              galleryRef.addImage({
                src: this.carouselImages[i].image,
                thumb: this.carouselImages[i].image
              });
            }
            if (this.carouselImages[i].type == "video") {
              galleryRef.addVideo({
                src: this.carouselImages[i].image,
                thumb: "../../assets/images/banner/static.jpg",
                poster: "../../assets/images/banner/static.jpg"
              });
            }
          }

          if (localStorage.getItem("loggedUser")) {
            var itemData = [];
            var count = 1;
            var isPush = true;
            var currentUser = localStorage.getItem("loggedUserEmail");
            var userData = JSON.parse(localStorage.getItem(currentUser));
            if (userData[0]["recentPrd"]) {
              itemData = userData[0]["recentPrd"];
              itemData.forEach(product => {
                if (product.productId == this.pId) {
                  product.count += 1;
                  isPush = false;
                }
              });
            }
            if (isPush) {
              itemData.push({
                productId: this.pId,
                name: this.prdName,
                sku: this.prdSku,
                price: this.prdPrice,
                image: this.mainImage,
                count: count
              });
            }

            userData[0]["recentPrd"] = itemData;
            localStorage.setItem(currentUser, JSON.stringify(userData));
          }
        }
      });
    });
    if (localStorage["loggedUser"] == "true") {
      this.loggedUser = !this.loggedUser;
      this.currentUser = localStorage.getItem("loggedUserEmail");
      this.username = JSON.parse(localStorage.getItem(this.currentUser))[0];
      this.userDetails = JSON.parse(localStorage.getItem(this.currentUser));
      this.compareProduct = this.userDetails[0].comparePrd;
      if (this.compareProduct && this.compareProduct.length > 0) {
        this.isCmprPrd = true;
        this.cmprCount = this.compareProduct.length;
      } else {
        this.isCmprPrd = false;
      }
    }
  }

  get f() {
    return this.addCart.controls;
  }

  buyNow() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.addCart.invalid) {
      return;
    }

    if (localStorage.getItem("loggedUser")) {
      var qVal = (<HTMLInputElement>document.getElementById("qtyValue")).value;
      var qty = parseInt(qVal);
      var isNum = /^\d+$/.test(qVal);
      if (isNum && qty != 0) {
        var cartData = [];
        var subTotal: number;
        var grandTotal: number;
        var totalQuantity;
        var shippingCharge: number;
        var shippingMethod;
        var isPush: boolean = false;
        var updateQty: number;
        var currentUser = localStorage.getItem("loggedUserEmail");
        var UserData = JSON.parse(localStorage.getItem(currentUser));
        localStorage.removeItem(currentUser);

        if (UserData[0]["cartData"]) {
          cartData = UserData[0]["cartData"]["productData"];
          isPush = true;
          cartData.forEach(product => {
            if (product.productId == this.pId) {
              updateQty = product.quantity + qty;
              if (updateQty > 0 && product.isDeleted == true) {
                product.quantity = qty;
                product.price = this.prdPrice * product.quantity;
                product.isDeleted = false;
              } else if (updateQty > 0) {
                product.quantity += qty;
                product.price = this.prdPrice * product.quantity;
                product.isDeleted = false;
              }
              isPush = false;
            }
          });
          var oldCart = UserData[0]["cartData"];
          subTotal = oldCart["subTotal"] + this.prdPrice * qty;
          grandTotal = oldCart["grandTotal"] + this.prdPrice * qty;
          totalQuantity = oldCart["totalQuantity"] + qty;
          shippingCharge = oldCart["shippingCharge"];
          shippingMethod = oldCart["shippingMethod"];
        } else {
          subTotal = this.prdPrice * qty;
          grandTotal = this.prdPrice * qty + 0;
          totalQuantity = qty;
          shippingCharge = 0;
          shippingMethod = "free";
          isPush = true;
        }
        if (isPush) {
          cartData.push({
            productId: this.pId,
            name: this.prdName,
            sku: this.prdSku,
            quantity: qty,
            price: this.prdPrice * qty,
            productPrice: this.prdPrice,
            image: this.mainImage,
            isDeleted: false
          });
        }

        var cart = {
          productData: cartData,
          subTotal: subTotal,
          grandTotal: grandTotal,
          totalQuantity: totalQuantity,
          shippingCharge: shippingCharge,
          shippingMethod: shippingMethod
        };

        if (!UserData[0]["cartData"]) {
          var supNode = document.createElement("span");
          supNode.classList.add("badge");
          supNode.classList.add("badge-notify");
          var textnode = document.createTextNode(totalQuantity);
          supNode.appendChild(textnode);
          document.getElementById("miniCart").appendChild(supNode);
        } else if (UserData[0]["cartData"].totalQuantity == 0) {
          var supNode = document.createElement("span");
          supNode.classList.add("badge");
          supNode.classList.add("badge-notify");
          var textnode = document.createTextNode(totalQuantity);
          supNode.appendChild(textnode);
          document.getElementById("miniCart").appendChild(supNode);
        } else {
          document.querySelector("#miniCart span").innerHTML = totalQuantity;
        }

        UserData[0]["cartData"] = cart;
        localStorage.setItem(currentUser, JSON.stringify(UserData));
        this.router.navigate(["/cart"]);
      } else {
        this.toastr.error("Please enter the valid number");
      }
    } else {
      let element = document.getElementById("signIn");
      element.click();
    }
  }
  addToCart() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.addCart.invalid) {
      return;
    }

    if (localStorage.getItem("loggedUser")) {
      var qVal = (<HTMLInputElement>document.getElementById("qtyValue")).value;
      var qty = parseInt(qVal);
      var isNum = /^\d+$/.test(qVal);
      if (isNum && qty != 0) {
        var cartData = [];
        var subTotal: number;
        var grandTotal: number;
        var totalQuantity;
        var shippingCharge: number;
        var shippingMethod;
        var maxQty: number = 5;
        var isPush: boolean = false;
        var updateQty: number;
        var currentUser = localStorage.getItem("loggedUserEmail");
        var UserData = JSON.parse(localStorage.getItem(currentUser));
        localStorage.removeItem(currentUser);

        if (UserData[0]["cartData"]) {
          cartData = UserData[0]["cartData"]["productData"];
          isPush = true;

          cartData.forEach(product => {
            if (product.productId == this.pId) {
              updateQty = product.quantity + qty;
              if (updateQty > 0 && product.isDeleted == true) {
                product.quantity = qty;
                product.price = this.prdPrice * product.quantity;
                product.isDeleted = false;
              } else if (updateQty > 0) {
                product.quantity += qty;
                product.price = this.prdPrice * product.quantity;
                product.isDeleted = false;
              }
              isPush = false;
            }
          });
          var oldCart = UserData[0]["cartData"];
          subTotal = oldCart["subTotal"] + this.prdPrice * qty;
          grandTotal = oldCart["grandTotal"] + this.prdPrice * qty;
          totalQuantity = parseInt(oldCart["totalQuantity"]) + qty;
          shippingCharge = oldCart["shippingCharge"];
          shippingMethod = oldCart["shippingMethod"];
        } else {
          subTotal = this.prdPrice * qty;
          grandTotal = this.prdPrice * qty + 0;
          totalQuantity = qty;
          shippingCharge = 0;
          shippingMethod = "free";
          isPush = true;
        }
        if (isPush) {
          cartData.push({
            productId: this.pId,
            name: this.prdName,
            sku: this.prdSku,
            quantity: qty,
            price: this.prdPrice,
            productPrice: this.prdPrice,
            image: this.mainImage,
            isDeleted: false
          });
        }

        var cart = {
          productData: cartData,
          subTotal: subTotal,
          grandTotal: grandTotal,
          totalQuantity: totalQuantity,
          shippingCharge: shippingCharge,
          shippingMethod: shippingMethod
        };

        if (!UserData[0]["cartData"]) {
          var supNode = document.createElement("span");
          supNode.classList.add("badge");
          supNode.classList.add("badge-notify");
          var textnode = document.createTextNode(totalQuantity);
          supNode.appendChild(textnode);
          document.getElementById("miniCart").appendChild(supNode);
        } else if (UserData[0]["cartData"].totalQuantity == 0) {
          var supNode = document.createElement("span");
          supNode.classList.add("badge");
          supNode.classList.add("badge-notify");
          var textnode = document.createTextNode(totalQuantity);
          supNode.appendChild(textnode);
          document.getElementById("miniCart").appendChild(supNode);
        } else {
          document.querySelector("#miniCart span").innerHTML = totalQuantity;
        }
        UserData[0]["cartData"] = cart;
        localStorage.setItem(currentUser, JSON.stringify(UserData));
        this.toastr.success("You have successfully added the item to the cart.");
      } else {
        this.toastr.error("Please enter the valid number");
      }
    } else {
      let element = document.getElementById("signIn");
      element.click();
    }
  }

  triggerClick() {
    let element = document.getElementById("signIn");
    element.click();
  }

  toggleSign(arg): void {
    let id = document.getElementById(arg);
    var src = id.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    id.setAttribute("src", src);
  }

  readMorebtn() {
    var moreCnt = document.getElementById("more");
    var readCnt = document.getElementById("read");
    if (moreCnt.style.display == "none") {
      readCnt.innerHTML = "Read less";
      moreCnt.style.display = "block";
    } else {
      readCnt.innerHTML = "Read more";
      moreCnt.style.display = "none";
    }
  }
  minusQty() {
    var value = parseInt(
      (<HTMLInputElement>document.getElementById("qtyValue")).value
    );
    if (value <= 1) {
      this.toastr.error("Please enter the valid number");
    } else {
      this.qtyValue = value - 1;
    }
  }
  plusQty() {
    var value = parseInt(
      (<HTMLInputElement>document.getElementById("qtyValue")).value
    );
    this.qtyValue = value + 1;
  }
  comparePrd() {
    if (localStorage.getItem("loggedUser")) {
      var comparePrd: any = [];
      var itemData = [];
      var count = 1;
      var isPush = true;
      var currentUser = localStorage.getItem("loggedUserEmail");
      var userData = JSON.parse(localStorage.getItem(currentUser));
      if (userData[0]["comparePrd"]) {
        itemData = userData[0]["comparePrd"];
        itemData.forEach(product => {
          if (product.productId == this.pId) {
            product.count += 1;
            isPush = false;
          }
        });
      }
      if (isPush) {
        itemData.push({
          productId: this.pId,
          name: this.prdName,
          sku: this.prdSku,
          price: this.prdPrice,
          image: this.mainImage,
          count: count
        });
      }
      userData[0]["comparePrd"] = itemData;
      if (!isPush) {
        this.toastr.warning("You cann't add the same product again");
      } else if (userData[0]["comparePrd"].length <= 3) {
        this.toastr.success(
          "You have successfully added the product to compare."
        );
        document.getElementById("header-compare").innerHTML =
          "Compare Product(" + userData[0]["comparePrd"].length + ")";
        localStorage.setItem(currentUser, JSON.stringify(userData));
      } else {
        this.toastr.error("Cann't add more than 3 products to compare");
      }
    } else {
      let element = document.getElementById("signIn");
      element.click();
    }
  }
}
