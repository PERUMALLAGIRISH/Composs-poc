import { Component, OnInit } from "@angular/core";
import { ProductserviceService } from "../services/product.services";
import { Iproduct, Ireview } from "./product";
import { PageChangedEvent } from "ngx-bootstrap/pagination";
import { ActivatedRoute, Router } from "@angular/router";
import { CategoriesService } from "../navigation/categories.service";
import { NgbRatingConfig } from "@ng-bootstrap/ng-bootstrap";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-product",
  templateUrl: "./product.component.html",
  styleUrls: ["./product.component.css"]
})
export class ProductComponent implements OnInit {
  products: Iproduct[] = [];
  sortName: boolean = true;
  sortPrice: boolean = true;
  sortStar: boolean = true;
  imgmar: number = 2;
  isActive: boolean = true;
  isAsc: number = 0;
  contentArray = new Array().fill("");
  returnedArray: Iproduct[];
  categoryFilter: Iproduct[];
  filteredProducts: Iproduct[];
  filteredBrandProducts: Iproduct[];
  filteredPriceProducts: Iproduct[];
  categoryProducts: Iproduct[];
  allProduct: Iproduct[];
  selectedBrandCheckBoxes = [];
  selectedPriceCheckBoxes = [];
  brands = [];
  brandsUnique;
  categoryName: any;
  pId;
  check: boolean = false;
  showCategories: boolean;
  showBrands: boolean;
  showPrices: boolean;
  status: boolean = false;
  throttle = 3000;
  scrollDistance = 1;
  selector: string = ".prd-list-panel";
  startEvent: number = 0;
  listView: boolean = false;
  gridView: boolean = true;
  stars: Ireview[];
  currentUser: string;
  loggedUser: boolean = false;
  userDetails: any;
  userName: any;
  compareProduct: any;
  isCmprPrd: boolean;
  cmprCount: number;

  constructor(
    private productService: ProductserviceService,
    private route: ActivatedRoute,
    private Ratingconfig: NgbRatingConfig,
    private CategoryService: CategoriesService,
    private router: Router,
    public toastr: ToastrService
  ) {
    Ratingconfig.max = 5;
    Ratingconfig.readonly = true;
  }

  ngOnInit() {
    this.route.params.subscribe(routeParams => {
      this.pId = routeParams.id;
      this.CategoryService.getCategories().subscribe(data => {
        this.categoryName = data.filter(
          category => category.categoryId == this.pId
        );
        this.categoryName = this.categoryName[0].name;
      });
      if (localStorage["loggedUser"] == "true") {
        this.loggedUser = !this.loggedUser;
        this.currentUser = localStorage.getItem("loggedUserEmail");
        this.userName = JSON.parse(localStorage.getItem(this.currentUser))[0];
        this.userDetails = JSON.parse(localStorage.getItem(this.currentUser));
        this.compareProduct = this.userDetails[0].comparePrd;
        if (this.compareProduct && this.compareProduct.length > 0) {
          this.isCmprPrd = true;
          this.cmprCount = this.compareProduct.length;
        } else {
          this.isCmprPrd = false;
        }
      }

      this.productService.getProducts().subscribe(data => {
        this.categoryFilter = data.filter(
          product => product.category_id == this.pId
        );
        this.products = this.categoryFilter;
        for (var brand = 0; brand < this.products.length; brand++) {
          this.brands.push(this.products[brand].brand);
        }
        this.brandsUnique = this.brands.filter(function (item, i, ar) {
          return ar.indexOf(item) === i;
        });
        this.contentArray = this.categoryFilter;
        this.returnedArray = this.contentArray.slice(0, 6);
      });
    });
  }

  //  Below commented code can be used for future reference
  // pageChanged(event: PageChangedEvent): void {
  //   const startItem = (event.page - 1) * event.itemsPerPage;
  //   const endItem = event.page * event.itemsPerPage;
  //   this.returnedArray = this.contentArray.slice(startItem, endItem);
  // }

  onScrollDown(event) {
    if (this.returnedArray.length < this.contentArray.length) {
      var add = this.returnedArray.length;
      this.returnedArray = this.returnedArray.concat(this.contentArray[add]);
    }
    this.startEvent = event.currentScrollPosition;
  }

  activeListView() {
    this.listView = true;
    this.gridView = false;
  }

  activeGridView() {
    this.listView = false;
    this.gridView = true;
  }

  toggleSign(arg): void {
    let id = document.getElementById(arg);
    var src = id.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    id.setAttribute("src", src);
  }

  sortByName() {
    this.status = !this.status;
    document.getElementById("drop-button").innerHTML = "&nbsp;Name";
    this.allProduct = this.contentArray;
    if (this.sortName === true) {
      this.allProduct.sort(this.sortByNameAsc);
      this.sortName = false;
      this.pageSlice(1, 6, this.allProduct);
    } else {
      this.allProduct.sort(this.sortByNameAsc).reverse();
      this.sortName = true;
      this.pageSlice(1, 6, this.allProduct);
    }
  }

  sortByNameAsc(a: Iproduct, b: Iproduct) {
    if (a.name > b.name) return 1;
    else if (a.name === b.name) return 0;
    else return -1;
  }

  sortByPrice() {
    this.status = !this.status;
    document.getElementById("drop-button").innerHTML = "&nbsp;Price";
    this.allProduct = this.contentArray;
    if (this.sortPrice === true) {
      this.allProduct.sort(this.sortByPriceAsc);
      this.sortPrice = false;
      this.pageSlice(1, 6, this.allProduct);
    } else {
      this.allProduct.sort(this.sortByPriceAsc).reverse();
      this.sortPrice = true;
      this.pageSlice(1, 6, this.allProduct);
    }
  }

  sortByPriceAsc(a: Iproduct, b: Iproduct) {
    if (a.price > b.price) return 1;
    else if (a.price === b.price) return 0;
    else return -1;
  }

  sortByStar() {
    this.status = !this.status;
    document.getElementById("drop-button").innerHTML = "&nbsp;Star Rating";
    this.allProduct = this.contentArray;
    if (this.sortStar === true) {
      this.allProduct.sort(this.sortByStarAsc);
      this.sortStar = false;
      this.pageSlice(1, 6, this.allProduct);
    } else {
      this.allProduct.sort(this.sortByStarAsc).reverse();
      this.sortStar = true;
      this.pageSlice(1, 6, this.allProduct);
    }
  }

  sortByStarAsc(a: Iproduct, b: Iproduct) {
    if (a.rating > b.rating) return 1;
    else if (a.rating === b.rating) return 0;
    else return -1;
  }

  sorting() {
    if (document.getElementById("drop-button").innerHTML === "&nbsp;Name") {
      this.sortByName();
    } else if (document.getElementById("drop-button").innerHTML === "&nbsp;Price") {
      this.sortByPrice();
    } else if (document.getElementById("drop-button").innerHTML === "&nbsp;Star Rating") {
      this.sortByStar();
    }
  }

  pageSlice(page, itemsPerPage, contentArray) {
    const startItem = (page - 1) * itemsPerPage;
    const endItem = page * itemsPerPage;
    this.returnedArray = contentArray.slice(startItem, endItem);
    return this.returnedArray;
  }

  sortProducts(eventData) {
    if (eventData === "brand") {
      this.check = true;
      var brandCheckboxes = document.querySelectorAll(
        'input[name="' + eventData + '"]:checked'
      ),
        brandValues = [];
      Array.prototype.forEach.call(brandCheckboxes, function (el) {
        brandValues.push(el.value);
      });
      this.selectedBrandCheckBoxes = brandValues;
      if (brandValues.length != 0) {
        this.filteredBrandProducts = this.products.filter(function (element) {
          return brandValues.indexOf(element.brand) > -1;
        });
      }
    } else if (eventData === "price") {
      this.check = true;
      var priceCheckboxes = document.querySelectorAll(
        'input[name="' + eventData + '"]:checked'
      ),
        priceValues = [];
      Array.prototype.forEach.call(priceCheckboxes, function (el) {
        priceValues.push(el.value);
      });
      this.selectedPriceCheckBoxes = priceValues;
      if (priceValues.length != 0) {
        var productsDataArr = [];
        this.filteredPriceProducts = this.products.filter(function (element) {
          var prodPrice = element.price;
          for (var i = 0; i < priceValues.length; i++) {
            var data = priceValues[i].split("to");
            var priceMinValue = parseInt(data[0]);
            var priceMaxValue = parseInt(data[1]);

            if (prodPrice >= priceMinValue && prodPrice <= priceMaxValue) {
              productsDataArr.push(element);
              return productsDataArr.slice(0, 6);
            }
          }
        });
      }
    }
    var brand = document.querySelectorAll(
      'input[name="' + "brand" + '"]:checked'
    );
    var price = document.querySelectorAll(
      'input[name="' + "price" + '"]:checked'
    );

    if (brand.length != 0 && price.length != 0) {
      var commonElementArray = [];
      var arr = [];
      var a = this.filteredBrandProducts;
      var b = this.filteredPriceProducts;
      for (var i = 0; i < a.length; i++) {
        for (var j = 0; j < b.length; j++) {
          if (a[i].productId === b[j].productId) {
            commonElementArray.push(a[i]);
          }
        }
      }
      this.contentArray = commonElementArray;
      this.returnedArray = commonElementArray.slice(0, 6);
    }
    if (brand.length != 0 && price.length == 0) {
      this.contentArray = this.filteredBrandProducts;
      this.returnedArray = this.filteredBrandProducts.slice(0, 6);
    }
    if (brand.length == 0 && price.length != 0) {
      this.contentArray = this.filteredPriceProducts;
      this.returnedArray = this.filteredPriceProducts.slice(0, 6);
    }
    if (brand.length == 0 && price.length == 0) {
      this.check = false;
      this.contentArray = this.products;
      this.returnedArray = this.products.slice(0, 6);
    }
  }

  disableBrandSelected(e) {
    var val = e.target.id;
    var eventData = document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).name;
    document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).checked = false;
    this.sortProducts(eventData);
  }

  disablePriceSelected(e) {
    var val = JSON.stringify(e.target.id);
    var eventData = document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).name;
    document.querySelector<HTMLInputElement>(
      "[value^=" + val + "]"
    ).checked = false;
    this.sortProducts(eventData);
  }

  clearAll() {
    if (document.querySelectorAll<HTMLInputElement>("[id^=selectedBrandCheck]")) {
      var elems = document.querySelectorAll<HTMLInputElement>(
        "[id^=selectedBrandCheck]"
      );
      for (var i = 0; i < elems.length; i++) {
        elems[i].remove();
      }
      var items = document.querySelectorAll<HTMLInputElement>("[name^=brand]");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type == "checkbox") items[i].checked = false;
      }
      var eventData = document.querySelector<HTMLInputElement>("[name^=brand]")
        .name;
      this.sortProducts(eventData);
    }

    if (document.querySelectorAll<HTMLInputElement>("[id^=selectedPriceCheck]")) {
      var elems = document.querySelectorAll<HTMLInputElement>(
        "[id^=selectedPriceCheck]"
      );
      for (var i = 0; i < elems.length; i++) {
        elems[i].remove();
      }
      var items = document.querySelectorAll<HTMLInputElement>("[name^=price]");
      for (var i = 0; i < items.length; i++) {
        if (items[i].type == "checkbox") items[i].checked = false;
      }
      var eventData = document.querySelector<HTMLInputElement>("[name^=price]")
        .name;
      this.sortProducts(eventData);
    }
  }

  toggleBrands() {
    this.showBrands = !this.showBrands;
  }

  toggleCategories() {
    this.showCategories = !this.showCategories;
  }

  togglePrices() {
    this.showPrices = !this.showPrices;
  }

  comparePrd(e) {
    if (localStorage.getItem("loggedUser")) {
      var id = e.target.id.split("-");
      var pId = id[1];
      var mainImage: string;
      var prdName: any;
      var prdSku: any;
      var prdPrice: number;
      this.returnedArray.forEach(product => {
        if (product["productId"] == pId) {
          mainImage = product["baseImages"][0];
          prdName = product["name"];
          prdSku = product["sku"];
          prdPrice = product["price"];
        }
      });
      var comparePrd: any = [];
      var itemData = [];
      var count = 1;
      var isPush = true;
      var currentUser = localStorage.getItem("loggedUserEmail");
      var userData = JSON.parse(localStorage.getItem(currentUser));
      if (userData[0]["comparePrd"]) {
        itemData = userData[0]["comparePrd"];
        itemData.forEach(product => {
          if (product.productId == pId) {
            product.count += 1;
            isPush = false;
          }
        });
      }
      if (isPush) {
        itemData.push({
          productId: pId,
          name: prdName,
          sku: prdSku,
          price: prdPrice,
          image: mainImage,
          count: count
        });
      }
      userData[0]["comparePrd"] = itemData;
      if (!isPush) {
        this.toastr.warning("You cann't add the same product again");
      } else if (userData[0]["comparePrd"].length <= 3) {
        this.toastr.success(
          "You have successfully added the product to compare."
        );
        document.getElementById("header-compare").innerHTML =
          "Compare Product(" + userData[0]["comparePrd"].length + ")";
        localStorage.setItem(currentUser, JSON.stringify(userData));
      } else {
        this.toastr.error("Cann't add more than 3 products to compare");
      }
    } else {
      let element = document.getElementById("signIn");
      element.click();
    }
  }
}
