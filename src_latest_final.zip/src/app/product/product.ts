export interface Iproduct {
  productId: string;
  name: string;
  sku: string;
  description: string;
  shortDescription: string;
  isFeatured: number;
  brand: string;
  price: number;
  rating: number;
  qty: number;
  color: string;
  size: string;
  weight: string;
  category_id: string;
  reviews: any;
  baseImages: any;
  thumbnailImages: any;
  relatedProducts: any;
}
export interface Ireview {
  reviews: [
    {
      name: string;
      rating: number;
      review: string;
    }
  ];
}
