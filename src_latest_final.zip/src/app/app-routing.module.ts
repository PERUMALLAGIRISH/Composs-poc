import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CheckoutComponent } from "./checkout/checkout.component";
import { RegisterComponent } from "./user/register/register.component";
import { LoginComponent } from "./user/login/login.component";
import { HomeComponent } from "./home/home.component";
import { ProductDetailComponent } from "./product/product-detail/product-detail.component";
import { CompareProductComponent } from "./product/compare-product/compare-product.component";
import { ProductComponent } from "./product/product.component";
import { CartComponent } from "./checkout/cart/cart.component";
import { SuccessComponent } from "./checkout/success/success.component";
import { SearchComponent } from "./product/search/search.component";
import { UserinformationComponent } from "./user/userinformation/userinformation.component";

const routes: Routes = [
  { path: "register", component: RegisterComponent },
  { path: "login", component: LoginComponent },
  { path: "", component: HomeComponent },
  { path: "category/:id", component: ProductComponent },
  { path: "product/:id", component: ProductDetailComponent },
  { path: "compare", component: CompareProductComponent },
  { path: "checkout", component: CheckoutComponent },
  { path: "cart", component: CartComponent },
  { path: "success", component: SuccessComponent },
  { path: "search/:id", component: SearchComponent },
  { path: "customer/:id", component: UserinformationComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
