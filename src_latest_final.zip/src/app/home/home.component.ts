import { Component, OnInit } from "@angular/core";
import { DeviceDetectorService } from "ngx-device-detector";

import { Category } from "../navigation/category";
import { Iproduct } from "../product/product";
import { Slider } from "./slider";
import { SliderService } from "../services/slider.services";
import { CategoriesService } from "../navigation/categories.service";
import { ProductserviceService } from "../services/product.services";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  chunkValue: number;
  activeSlideIndex: number = 0;
  myInterval: number = 2500;
  errorMessage: string;
  showIcon: boolean = false;
  isMobile: boolean = false;
  isTablet: boolean = false;
  sliderArray: Slider[];
  categoriesList: Category[];
  featureProduct: Iproduct[];

  constructor(
    public slider: SliderService,
    private categoriesService: CategoriesService,
    private Productservice: ProductserviceService,
    private deviceService: DeviceDetectorService
  ) {
    this.sliderArray = [];
  }

  ngOnInit() {
    document.getElementById("navbar").style.display = "flex";

    this.isMobile = this.deviceService.isMobile();
    this.isTablet = this.deviceService.isTablet();
    var window_with = window.outerWidth;
    this.slider.getSlider().subscribe((result: Slider[] = []) => {
      this.sliderArray = result;
    });

    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
      },
      error => (this.errorMessage = <string>error)
    );
    //based on the window size set the chunk value
    if (window_with <= 480) {
      this.chunkValue = 1;
    } else if (window_with <= 768) {
      this.chunkValue = 2;
    } else {
      this.chunkValue = 3;
    }

    this.Productservice.getProducts().subscribe(data => {
      this.featureProduct = this.chunks(data, this.chunkValue);
    });

    var dots = document.getElementById("more");
    dots.style.display = "none";
  }
  // chunk array for slider data
  chunks(array, size) {
    let results = [];
    results = [];
    while (array.length) {
      results.push(array.splice(0, size));
    }
    return results;
  }
  //change wishlist icon dynamicly
  addToWishList(arg): void {
    let id = document.getElementById(arg);
    var src = id.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    id.setAttribute("src", src);
  }
  //change readmore & readless content dynamicly
  ReadMoreBtn() {
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("readMoreTextBtn");
    if (moreText.style.display == "none") {
      btnText.innerHTML = "Read less";
      moreText.style.display = "block";
    } else {
      btnText.innerHTML = "Read more";
      moreText.style.display = "none";
    }
  }
  // change preview & next icon color
  preNextIconChange() {
    this.showIcon = !this.showIcon;
  }
}
