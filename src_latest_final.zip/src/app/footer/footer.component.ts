import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "../../../node_modules/@angular/forms";
import { ToastrService } from "../../../node_modules/ngx-toastr";

@Component({
  selector: "app-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.css"]
})

export class FooterComponent implements OnInit {
  newsLetterForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder, private toastr: ToastrService) { }

  ngOnInit() {
    this.newsLetterForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]]
    });
  }

  get f() {
    return this.newsLetterForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.newsLetterForm.invalid) {
      return;
    }
    var email = this.newsLetterForm.value.email;

    if (email) {
      this.toastr.success("You have successfully subscribed to the newsletter.");
    }
  }
}
