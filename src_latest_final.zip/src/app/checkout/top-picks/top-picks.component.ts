import { Component, OnInit } from "@angular/core";
import { DeviceDetectorService } from "ngx-device-detector";

import { CategoriesService } from "../../navigation/categories.service";
import { Category } from "../../navigation/category";
import { Iproduct } from "../../product/product";
import { SliderService } from "../../services/slider.services";
import { ProductserviceService } from "../../services/product.services";
import { Slider } from "./slider";
import { TopPicksService } from "./top-picks.service";

@Component({
  selector: "app-top-picks",
  templateUrl: "./top-picks.component.html",
  styleUrls: ["./top-picks.component.css"]
})
export class TopPicksComponent implements OnInit {
  sliderArray: Slider[];
  categoriesList: Category[];
  myInterval: number = 2500;
  activeSlideIndex = 0;
  errorMessage: any;
  featureProduct: Iproduct[];
  filteredItems: any;
  showIcon: boolean = false;
  currentUser: string;
  updatedCartList: any;
  updatedCartall: any;
  recentProduct: any;
  productData: any = [];
  productId: any;
  isMobile: boolean = false;
  chunksValue: number;
  isTablet: boolean = false;

  constructor(
    public slider: SliderService,
    private categoriesService: CategoriesService,
    private productService: ProductserviceService,
    private relatedProductsService: TopPicksService,
    private deviceService: DeviceDetectorService
  ) {
    this.sliderArray = [];
  }

  ngOnInit() {
    this.isMobile = this.deviceService.isMobile();
    this.isTablet = this.deviceService.isTablet();
    var window_with = window.outerWidth;
    this.slider.getSlider().subscribe((result: Slider[] = []) => {
      this.sliderArray = result;
      this.sliderArray = this.sliderArray;
    });
    this.categoriesService.getCategories().subscribe(
      data => {
        this.categoriesList = data;
      },
      error => (this.errorMessage = <any>error)
    );
    this.productService.getProducts().subscribe(data => {
      this.productData = data;
      this.currentUser = localStorage.getItem("loggedUserEmail");
      this.updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
      this.updatedCartList = this.updatedCartall[0].cartData;
      let productList = [];
      for (let i = 0; i < this.updatedCartList.productData.length; i++) {
        this.productId = this.updatedCartList.productData[i].productId;
        productList.push(this.productId);
      }
      let matchProduct: any;
      let productsData: any = [];
      for (let i = 0; i < productList.length; i++) {
        matchProduct = this.productData.filter(
          product => product.productId == productList[i]
        );
        let value = matchProduct[0].relatedProducts.replace('"', "") + ",";
        productsData = productsData + value;
      }
      productsData = productsData.split(",");
      this.productId = removeDuplicates(productsData);
      function removeDuplicates(products) {
        let uniqueProductList = [];
        for (let i = 0; i < products.length; i++) {
          if (uniqueProductList.indexOf(products[i]) == -1) {
            uniqueProductList.push(products[i]);
          }
        }
        return uniqueProductList;
      }
      let finalProductData = [];
      let finalNewProductData = [];
      for (let i = 0; i < this.productId.length - 1; i++) {
        finalProductData = this.productData.filter(
          product => product.productId == this.productId[i]
        );
        finalNewProductData.push(finalProductData[0]);
      }
      this.featureProduct = this.chunks(finalNewProductData, this.chunksValue);
    });

    if (window_with <= 480) {
      this.chunksValue = 1;
    } else if (window_with <= 768) {
      this.chunksValue = 2;
    } else {
      this.chunksValue = 3;
    }

    this.currentUser = localStorage.getItem("loggedUserEmail");
    this.updatedCartall = JSON.parse(localStorage.getItem(this.currentUser));
    this.updatedCartList = this.updatedCartall[0].recentPrd;
    this.updatedCartList.sort(this.sortByCount).reverse();
    this.recentProduct = this.chunks(this.updatedCartList, this.chunksValue);
  }

  chunks(productData, size) {
    let results = [];
    results = [];
    while (productData.length) {
      results.push(productData.splice(0, size));
    }
    return results;
  }

  sortByCount(a: any, b: any) {
    if (a.count > b.count) return 1;
    else if (a.count === b.count) return 0;
    else return -1;
  }

  toggleSign(arg): void {
    let wishlistId = document.getElementById(arg);
    var src = wishlistId.getAttribute("src");
    if (src == "assets/icons/heartNormal.svg") {
      src = "assets/icons/heartSelected.svg";
    } else {
      src = "assets/icons/heartNormal.svg";
    }
    wishlistId.setAttribute("src", src);
  }

  toggleImage() {
    this.showIcon = !this.showIcon;
  }
}
