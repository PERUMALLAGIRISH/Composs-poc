import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { PaginationModule } from "ngx-bootstrap/pagination";
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";

import { CheckoutComponent } from "./checkout.component";
import { CartComponent } from "./cart/cart.component";
import { SuccessComponent } from "./success/success.component";
import { AppRoutingModule } from "../app-routing.module";
import { TopPicksComponent } from "./top-picks/top-picks.component";

@NgModule({
  declarations: [
    CheckoutComponent,
    CartComponent,
    SuccessComponent,
    TopPicksComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    PaginationModule.forRoot(),
    BsDropdownModule.forRoot(),
    ToastrModule.forRoot(),
    AppRoutingModule
  ]
})
export class CheckoutModule { }
