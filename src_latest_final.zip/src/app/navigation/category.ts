export interface Category {
  id: number;
  name: string;
  categoryId: number;
}
